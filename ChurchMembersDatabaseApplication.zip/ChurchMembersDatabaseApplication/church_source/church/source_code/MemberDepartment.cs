using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
namespace DCM
{
    public partial class MemberDepartment : Form
    {
        public MemberDepartment()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            label2.Text = "";

            string STRMEMBERID = this.textBox1.Text;
            if (STRMEMBERID.Trim().Length > 0)
            {
            String ssql = "SELECT Member_id, Firstname, Middlename, Lastname, Gender, MaritalStatus,  ";
                ssql = ssql + "  Genotype, DateOfBirth, BloodGroup, Street1, Street2, LGACounty,  ";
                ssql = ssql + "  State, Country, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,   ";
                ssql = ssql + "  MobileNumber4, SpouseMobileNumber1, SpouseMobileNumber2, AreYouBornAgain,  ";
                ssql = ssql + "  AreYouBaptizedByImmersion, AreYouBaptizedByHolySpirit, EmploymentStatus,   ";
                ssql = ssql + "  PlaceOfWork, PlaceOfWorkAddress, PlaceOfWorkPhone, Profession,  ";
                ssql = ssql + "  DateJoined, Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup,   ";
                ssql = ssql + "  Reason, StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,  ";
                ssql = ssql + "  StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,  ";
                ssql = ssql + "  StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,  ";
                ssql = ssql + "  emailaddress1, emailaddress2, emailaddress3   ";

                ssql = ssql + "  FROM ChurchMembers  ";

                ssql = ssql + "  where Member_id  = " + STRMEMBERID;

              
                SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                                    "password=;server=localhost;" +
                                                    "Trusted_Connection=yes;" +
                                                    "database=CHurch; " +
                                                    "connection timeout=30");

                myConnection.Open();
                SqlCommand sc = new SqlCommand(ssql, myConnection);
                SqlDataReader reader = sc.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);

                dataGridView1.DataSource = dt;

                if (dt.Rows.Count <= 0)
                {
                    MessageBox.Show("The MEMBER ID does not exist please search  members database to get the accurate member id!!!!!");
                    this.textBox1.Focus();
                }

                label2.Text = STRMEMBERID;

                reader.Close();
                sc.Dispose();
                myConnection.Close();
            }else
            {
                MessageBox.Show("Please Enter the MEMBERID");
            }


            /////////////////////////////////////////
            ////////SET UP THE LIST VIEW  FR THE LIST OF DEPARMENT AND GROUPS
            this.listView1.Columns.Clear();
            this.listView1.Columns.Add("DEPTCODE", 0);
            this.listView1.Columns.Add("GROUPCODE", 0);
            this.listView1.Columns.Add("DEPTNAME", 250);
            this.listView1.Columns.Add("GROUPNAME", 250);

            this.listView2.Columns.Clear();
            this.listView2.Columns.Add("DEPTCODE", 0);
            this.listView2.Columns.Add("GROUPCODE", 0);
            this.listView2.Columns.Add("DEPTNAME", 250);
            this.listView2.Columns.Add("GROUPNAME", 250);

            if (label2.Text.Trim().Length > 0)
            {
                String ssqlM = "SELECT  A.DEPT_CODE,B.group_CODE, A.DEPT_NAME,   ";
                ssqlM = ssqlM + "  B.group_NAME, B.STATUS ,A.STATUS,A.DEPT_id, B.group_id,  A.Group_cOde   ";
                ssqlM = ssqlM + "FROM DEPARTMENT  A, [GROUP] B  ";
                ssqlM = ssqlM + "WHERE B.STATUS=A.STATUS  ";
                ssqlM = ssqlM + "AND A.Group_cOde =B.group_CODE  ";

                ssqlM = ssqlM + "AND A.DEPT_CODE NOT IN (SELECT DEPT_CODE FROM MEMBER_DEPARTMENT WHERE member_id= " + label2.Text + ")  ";

                ssqlM = ssqlM + "AND B.STATUS='A'   ORDER BY B.group_CODE asC ";

                SqlConnection myConnectionMDG = new SqlConnection("user id=dbo;" +
                                                        "password=;server=localhost;" +
                                                        "Trusted_Connection=yes;" +
                                                        "database=CHurch; " +
                                                        "connection timeout=30");

                myConnectionMDG.Open();
                SqlCommand sc1 = new SqlCommand(ssqlM, myConnectionMDG);
                SqlDataReader reader1 = sc1.ExecuteReader();
                this.listView1.Items.Clear();
                while (reader1.Read())
                {
                    string[] STR = new string[4];
                    STR[0] = reader1.GetValue(0).ToString().ToUpper();
                    STR[1] = reader1.GetValue(1).ToString().ToUpper();
                    STR[2] = reader1.GetValue(2).ToString().ToUpper();
                    STR[3] = reader1.GetValue(3).ToString().ToUpper();

                    ListViewItem ll = new ListViewItem(STR);

                    this.listView1.Items.Add(ll);
                }

                ////////////////////////POPULATE THE ORIGINAL ATTACHED DEPART ;LINKED TO THE MEMBER 

                SqlConnection myConnectionMDG1 = new SqlConnection("user id=dbo;" +
                                            "password=;server=localhost;" +
                                            "Trusted_Connection=yes;" +
                                            "database=CHurch; " +
                                            "connection timeout=30");

                myConnectionMDG1.Open();

                String ssqlMD = "SELECT  A.DEPT_CODE,B.group_CODE, A.DEPT_NAME,   ";
                ssqlMD = ssqlMD + "  c.group_NAME   ";
                ssqlMD = ssqlMD + "FROM DEPARTMENT  A, MEMBER_DEPARTMENT B, [group] c  ";
                ssqlMD = ssqlMD + "WHERE 1=1 ";
                ssqlMD = ssqlMD + "AND A.Group_cOde =B.group_CODE  ";
                ssqlMD = ssqlMD + "AND A.DEPT_CODE =B.DEPT_CODE  ";
                ssqlMD = ssqlMD + "AND A.group_CODE =c.group_CODE  ";
                //ssqlMD = ssqlMD +  "AND A.STATUS ='A' ";

                ssqlMD = ssqlMD + "AND B.MEMBER_ID = " + label2.Text + " ";
                ssqlMD = ssqlMD + "  ORDER BY A.group_CODE asC ";


                SqlCommand sc2 = new SqlCommand(ssqlMD, myConnectionMDG1);
                SqlDataReader reader2 = sc2.ExecuteReader();
                this.listView2.Items.Clear();
                while (reader2.Read())
                {
                    string[] STR = new string[4];
                    STR[0] = reader2.GetValue(0).ToString().ToUpper();
                    STR[1] = reader2.GetValue(1).ToString().ToUpper();
                    STR[2] = reader2.GetValue(2).ToString().ToUpper();
                    STR[3] = reader2.GetValue(3).ToString().ToUpper();

                    ListViewItem ll = new ListViewItem(STR);

                    this.listView2.Items.Add(ll);
                }


                sc1.Cancel();
                sc1.Cancel();
                sc2.Cancel();

                reader1.Close();
                reader2.Close();

                myConnectionMDG.Close();
                myConnectionMDG1.Close();
            }

//////////////////////////////////////////////////////////////


        }

        private void button1_Click(object sender, EventArgs e)
        {
            copyselectediitems(listView1, listView2);

            //ListViewItem itemsel = this.listView1.Select.
           
            //ListViewItem itemselclone = itemsel.Clone() as ListViewItem;
            //listView2.Items.Add(itemselclone);
            //listView21.Items.Remove(itemsel);


        }

        private static void copyselectediitems(ListView source, ListView target)
        {
        ////foreach(ListView item in source.SelectedItems)
        ////{
        ////target.Items.Add((ListViewItem)item.Clone());
        ////}

            while (source.SelectedItems.Count > 0)
            {
                ListViewItem temp = source.SelectedItems[0];
                source.Items.Remove(temp);
                target.Items.Add(temp);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            copyselectediitems(listView2, listView1);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
            
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && (sender as TextBox).Text.IndexOf('.') < -1)
            {
                e.Handled = true;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (listView2.Items.Count > 0 && this.dataGridView1.RowCount > 0)
            {

                SqlConnection myConnectionMDG = new SqlConnection("user id=dbo;" +
                                            "password=;server=localhost;" +
                                            "Trusted_Connection=yes;" +
                                            "database=CHurch; " +
                                            "connection timeout=30");

                myConnectionMDG.Open();

                ///////// first delete previous record....
                SqlCommand sc3 = new SqlCommand("delete from MEMBER_DEPARTMENT where [member_id]= " + label2.Text, myConnectionMDG);
                sc3.ExecuteNonQuery();
                SqlCommand sc4 = new SqlCommand("commit", myConnectionMDG);
                sc3.ExecuteNonQuery();


                foreach (ListViewItem item in listView2.Items)
                {
                    // string[] STR = new string[4];
                    //  STR = (string[])item;
                    String deptcode = item.Text;
                    String groupcode = item.SubItems[1].Text;
                    String memberid = this.label2.Text;
                    String SQLINSERT = "INSERT INTO MEMBER_DEPARTMENT([member_id], [DEPT_CODE], [group_CODE])";
                    SQLINSERT = SQLINSERT + " VALUES(" + memberid + ", '" + deptcode + "', '" + groupcode + "')";
                    SqlCommand sc1 = new SqlCommand(SQLINSERT, myConnectionMDG);
                    sc1.ExecuteNonQuery();
                    sc1.Dispose();
                    sc3.Dispose();
                    sc4.Dispose();


                }

                MessageBox.Show("Successfully assign memeber to " + listView2.Items.Count + " Department(s)");
                listView2.Items.Clear();
                listView1.Items.Clear();
                this.textBox1.Text = "";
                this.dataGridView1.DataSource = null;

                this.label2.Text = "";
                myConnectionMDG.Close();
                myConnectionMDG.Dispose();
            }
            else {
                MessageBox.Show("Get accurate member id . You cant add empty record to the database!!!!!!!");
            }

        }
    }
}