namespace DCM
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbAssign5 = new System.Windows.Forms.ComboBox();
            this.cmbAssign4 = new System.Windows.Forms.ComboBox();
            this.cmbAssign3 = new System.Windows.Forms.ComboBox();
            this.cmbAssign2 = new System.Windows.Forms.ComboBox();
            this.txtQryValue5 = new System.Windows.Forms.TextBox();
            this.cmbField5 = new System.Windows.Forms.ComboBox();
            this.cmbConjunction5 = new System.Windows.Forms.ComboBox();
            this.txtQryValue4 = new System.Windows.Forms.TextBox();
            this.cmbField4 = new System.Windows.Forms.ComboBox();
            this.cmbConjunction4 = new System.Windows.Forms.ComboBox();
            this.txtQryValue3 = new System.Windows.Forms.TextBox();
            this.cmbField3 = new System.Windows.Forms.ComboBox();
            this.cmbConjunction3 = new System.Windows.Forms.ComboBox();
            this.txtQryValue2 = new System.Windows.Forms.TextBox();
            this.cmbField2 = new System.Windows.Forms.ComboBox();
            this.cmbConjunction2 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // cmbAssign5
            // 
            this.cmbAssign5.FormattingEnabled = true;
            this.cmbAssign5.Items.AddRange(new object[] {
            "=",
            ">=",
            "<=",
            ">",
            "<",
            "<>",
            "LIKE"});
            this.cmbAssign5.Location = new System.Drawing.Point(432, 164);
            this.cmbAssign5.Name = "cmbAssign5";
            this.cmbAssign5.Size = new System.Drawing.Size(121, 21);
            this.cmbAssign5.TabIndex = 40;
            // 
            // cmbAssign4
            // 
            this.cmbAssign4.FormattingEnabled = true;
            this.cmbAssign4.Items.AddRange(new object[] {
            "=",
            ">=",
            "<=",
            ">",
            "<",
            "<>",
            "LIKE"});
            this.cmbAssign4.Location = new System.Drawing.Point(432, 137);
            this.cmbAssign4.Name = "cmbAssign4";
            this.cmbAssign4.Size = new System.Drawing.Size(121, 21);
            this.cmbAssign4.TabIndex = 39;
            // 
            // cmbAssign3
            // 
            this.cmbAssign3.FormattingEnabled = true;
            this.cmbAssign3.Items.AddRange(new object[] {
            "=",
            ">=",
            "<=",
            ">",
            "<",
            "<>",
            "LIKE"});
            this.cmbAssign3.Location = new System.Drawing.Point(432, 110);
            this.cmbAssign3.Name = "cmbAssign3";
            this.cmbAssign3.Size = new System.Drawing.Size(121, 21);
            this.cmbAssign3.TabIndex = 38;
            // 
            // cmbAssign2
            // 
            this.cmbAssign2.FormattingEnabled = true;
            this.cmbAssign2.Items.AddRange(new object[] {
            "=",
            ">=",
            "<=",
            ">",
            "<",
            "<>",
            "LIKE"});
            this.cmbAssign2.Location = new System.Drawing.Point(432, 83);
            this.cmbAssign2.Name = "cmbAssign2";
            this.cmbAssign2.Size = new System.Drawing.Size(121, 21);
            this.cmbAssign2.TabIndex = 37;
            // 
            // txtQryValue5
            // 
            this.txtQryValue5.Location = new System.Drawing.Point(580, 164);
            this.txtQryValue5.Name = "txtQryValue5";
            this.txtQryValue5.Size = new System.Drawing.Size(335, 20);
            this.txtQryValue5.TabIndex = 36;
            // 
            // cmbField5
            // 
            this.cmbField5.FormattingEnabled = true;
            this.cmbField5.Location = new System.Drawing.Point(217, 163);
            this.cmbField5.Name = "cmbField5";
            this.cmbField5.Size = new System.Drawing.Size(179, 21);
            this.cmbField5.TabIndex = 35;
            // 
            // cmbConjunction5
            // 
            this.cmbConjunction5.FormattingEnabled = true;
            this.cmbConjunction5.Items.AddRange(new object[] {
            "     ",
            "AND",
            "OR"});
            this.cmbConjunction5.Location = new System.Drawing.Point(129, 163);
            this.cmbConjunction5.Name = "cmbConjunction5";
            this.cmbConjunction5.Size = new System.Drawing.Size(85, 21);
            this.cmbConjunction5.TabIndex = 34;
            // 
            // txtQryValue4
            // 
            this.txtQryValue4.Location = new System.Drawing.Point(580, 137);
            this.txtQryValue4.Name = "txtQryValue4";
            this.txtQryValue4.Size = new System.Drawing.Size(335, 20);
            this.txtQryValue4.TabIndex = 33;
            // 
            // cmbField4
            // 
            this.cmbField4.FormattingEnabled = true;
            this.cmbField4.Location = new System.Drawing.Point(217, 136);
            this.cmbField4.Name = "cmbField4";
            this.cmbField4.Size = new System.Drawing.Size(179, 21);
            this.cmbField4.TabIndex = 32;
            // 
            // cmbConjunction4
            // 
            this.cmbConjunction4.FormattingEnabled = true;
            this.cmbConjunction4.Items.AddRange(new object[] {
            "     ",
            "AND",
            "OR"});
            this.cmbConjunction4.Location = new System.Drawing.Point(129, 136);
            this.cmbConjunction4.Name = "cmbConjunction4";
            this.cmbConjunction4.Size = new System.Drawing.Size(85, 21);
            this.cmbConjunction4.TabIndex = 31;
            // 
            // txtQryValue3
            // 
            this.txtQryValue3.Location = new System.Drawing.Point(580, 110);
            this.txtQryValue3.Name = "txtQryValue3";
            this.txtQryValue3.Size = new System.Drawing.Size(335, 20);
            this.txtQryValue3.TabIndex = 30;
            // 
            // cmbField3
            // 
            this.cmbField3.FormattingEnabled = true;
            this.cmbField3.Location = new System.Drawing.Point(217, 109);
            this.cmbField3.Name = "cmbField3";
            this.cmbField3.Size = new System.Drawing.Size(179, 21);
            this.cmbField3.TabIndex = 29;
            // 
            // cmbConjunction3
            // 
            this.cmbConjunction3.FormattingEnabled = true;
            this.cmbConjunction3.Items.AddRange(new object[] {
            "     ",
            "AND",
            "OR"});
            this.cmbConjunction3.Location = new System.Drawing.Point(129, 109);
            this.cmbConjunction3.Name = "cmbConjunction3";
            this.cmbConjunction3.Size = new System.Drawing.Size(85, 21);
            this.cmbConjunction3.TabIndex = 28;
            // 
            // txtQryValue2
            // 
            this.txtQryValue2.Location = new System.Drawing.Point(580, 83);
            this.txtQryValue2.Name = "txtQryValue2";
            this.txtQryValue2.Size = new System.Drawing.Size(335, 20);
            this.txtQryValue2.TabIndex = 27;
            // 
            // cmbField2
            // 
            this.cmbField2.FormattingEnabled = true;
            this.cmbField2.Location = new System.Drawing.Point(217, 82);
            this.cmbField2.Name = "cmbField2";
            this.cmbField2.Size = new System.Drawing.Size(179, 21);
            this.cmbField2.TabIndex = 26;
            // 
            // cmbConjunction2
            // 
            this.cmbConjunction2.FormattingEnabled = true;
            this.cmbConjunction2.Items.AddRange(new object[] {
            "     ",
            "AND",
            "OR"});
            this.cmbConjunction2.Location = new System.Drawing.Point(129, 82);
            this.cmbConjunction2.Name = "cmbConjunction2";
            this.cmbConjunction2.Size = new System.Drawing.Size(85, 21);
            this.cmbConjunction2.TabIndex = 25;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1045, 266);
            this.Controls.Add(this.cmbAssign5);
            this.Controls.Add(this.cmbAssign4);
            this.Controls.Add(this.cmbAssign3);
            this.Controls.Add(this.cmbAssign2);
            this.Controls.Add(this.txtQryValue5);
            this.Controls.Add(this.cmbField5);
            this.Controls.Add(this.cmbConjunction5);
            this.Controls.Add(this.txtQryValue4);
            this.Controls.Add(this.cmbField4);
            this.Controls.Add(this.cmbConjunction4);
            this.Controls.Add(this.txtQryValue3);
            this.Controls.Add(this.cmbField3);
            this.Controls.Add(this.cmbConjunction3);
            this.Controls.Add(this.txtQryValue2);
            this.Controls.Add(this.cmbField2);
            this.Controls.Add(this.cmbConjunction2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbAssign5;
        private System.Windows.Forms.ComboBox cmbAssign4;
        private System.Windows.Forms.ComboBox cmbAssign3;
        private System.Windows.Forms.ComboBox cmbAssign2;
        private System.Windows.Forms.TextBox txtQryValue5;
        private System.Windows.Forms.ComboBox cmbField5;
        private System.Windows.Forms.ComboBox cmbConjunction5;
        private System.Windows.Forms.TextBox txtQryValue4;
        private System.Windows.Forms.ComboBox cmbField4;
        private System.Windows.Forms.ComboBox cmbConjunction4;
        private System.Windows.Forms.TextBox txtQryValue3;
        private System.Windows.Forms.ComboBox cmbField3;
        private System.Windows.Forms.ComboBox cmbConjunction3;
        private System.Windows.Forms.TextBox txtQryValue2;
        private System.Windows.Forms.ComboBox cmbField2;
        private System.Windows.Forms.ComboBox cmbConjunction2;
    }
}