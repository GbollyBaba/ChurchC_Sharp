using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DCM
{
    public partial class mainform : Form
    {
        public mainform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 FF = new Form1();
            FF.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Depandent FF = new Depandent();
            FF.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MemberDepartment FF = new MemberDepartment();
            FF.Show();
        }

        private void mainform_Load(object sender, EventArgs e)
        {

        }
    }
}