using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DCM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button2.Enabled = false;


            ///populate the search fields
            ///
            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                  "password=;server=localhost;" +
                                  "Trusted_Connection=yes;" +
                                  "database=CHurch; " +
                                  "connection timeout=30");
            SqlConnection myConnection1 = new SqlConnection("user id=dbo;" +
                            "password=;server=localhost;" +
                            "Trusted_Connection=yes;" +
                            "database=CHurch; " +
                            "connection timeout=30");

            myConnection.Open();
            myConnection1.Open();
            String ssql = " select fieldname from MYCOLUMN  where mytablename='CHURCHMEMBERS'  ";
          
            SqlCommand sc = new SqlCommand(ssql, myConnection);
            SqlDataReader reader = sc.ExecuteReader();
            DataTable dt = new DataTable();

            SqlCommand sc1 = new SqlCommand(ssql, myConnection1);
            SqlDataReader reader1 = sc1.ExecuteReader();
            DataTable dt1 = new DataTable();


            dt.Columns.Add("fieldname", typeof(string));
            dt.Load(reader);


            dt1.Columns.Add("fieldname", typeof(string));
            dt1.Load(reader1);

           
            cmbField1.ValueMember = "fieldname";
                cmbField2.ValueMember = "fieldname";
                cmbField1.DisplayMember = "fieldname";
                cmbField2.DisplayMember = "fieldname";
            cmbField1.DataSource = dt;
                cmbField2.DataSource =  dt1;


            reader.Close();
            sc.Dispose();
            myConnection.Close();

            reader1.Close();
            sc1.Dispose();
            myConnection1.Close();

            ///SELT THE ITEM TO THE FIRST RECORD IN THE DATATABLE
            cmbField1.SelectedIndex = 0;
            cmbField2.SelectedIndex = 0;
            cmbAssign1.SelectedIndex = 0;
            cmbAssign2.SelectedIndex = 0;


            SqlConnection myConnection3 = new SqlConnection("user id=dbo;" +
                                   "password=;server=localhost;" +
                                   "Trusted_Connection=yes;" +
                                   "database=CHurch; " +
                                   "connection timeout=30");

            myConnection3.Open();
            String ssql3 = " SELECT  DISTINCT [PrefferedGroup_shortname] FROM [Church].[dbo].[PrefferedGroup]   ";
           
            SqlCommand sc3 = new SqlCommand(ssql3, myConnection3);
            SqlDataReader reader3 = sc3.ExecuteReader();
            DataTable dt3 = new DataTable();

            dt3.Columns.Add("PrefferedGroup_shortname", typeof(string));
            dt3.Load(reader3);
            cmdPREFERREDGROUP.ValueMember = "PrefferedGroup_shortname";
            cmdPREFERREDGROUP.DisplayMember = "PrefferedGroup_shortname";
            cmdPREFERREDGROUP.DataSource = dt3;

            reader3.Close();
            sc3.Dispose();
            myConnection3.Close();

            
            
            /////dis able the search fileds
            //cmbConjunction2.
            ////cmbField2.Visible=false;
            ////cmbAssign2.Visible=false;
            ////txtQryValue2.Visible = false;

            ////cmbConjunction3.Visible = false;
            ////cmbField3.Visible = false;
            ////cmbAssign3.Visible = false;
            ////txtQryValue3.Visible = false;

            ////cmbConjunction4.Visible = false;
            ////cmbField4.Visible = false;
            ////cmbAssign4.Visible = false;
            ////txtQryValue4.Visible = false;

            ////cmbConjunction5.Visible = false;
            ////cmbField5.Visible = false;
            ////cmbAssign5.Visible = false;
            ////txtQryValue5.Visible = false;




        }

        private void ClearFields()
        {
            this.LBLMEMBERID.Text = "";
         this.txtFIRSTNAME.Text="";
 this.txtMIDDLENAME.Text="";
 this.txtSURNAME.Text="";
 this.cmbGENDER.Text="";
 this.cmbMARITALSTATUS.Text="";
 this.cmbGENOTYPE.Text="";
 this.dtpDATEOFBIRTH.Value = DateTime.Now;
 this.cmbBLOODGROUP.Text="";
 this.txtSTREET1.Text="";
 this.txtSTREET2.Text="";
 this.txtLGACounty.Text="";
 this.txtSTATE1.Text="";
 this.txtCOUNTRY1.Text="";
 this.txtTITHECARDNUMBER.Text="";
 this.txtMOBILENUMBER1.Text="";
 this.txtMOBILENUMBER2.Text="";
 this.txtMOBILENUMBER3.Text="";
 this.txtMOBILENUMBER4.Text="";
 this.txtSPOUSEMOBILENUMBER1.Text="";
 this.txtSPOUSEMOBILENUMBER2.Text="";
 this.cmbAREYOUBORNAGAIN.Text="";
 this.cmbAREYOUBAPTIZEDBYIMMERSION.Text="";
 this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Text="";
 this.cmbEMPLOYEESTATUS.Text="";
 this.txtPLACEOFWORK.Text="";
 this.txtPLACEOFWORKADDRESS.Text="";
 this.txtPLACEOFWORKPHONENUMBERS.Text="";
 this.txtPLACEOFWORKPROFESSION.Text="";
 this.dtpDATEJOINED.Value=DateTime.Now;
 this.txtHOBBIESANDINTEREST.Text="";
 this.txtSPECIALSKILLS.Text="";
 this.txtSPIRITUALGIFTS.Text="";
 this.cmdPREFERREDGROUP.Text="";
 this.txtREASON.Text="";
 this.cmdStudentOrGraduate1.Text="";
 this.txtACADEMICINSTITUTION1.Text="";
 this.txtCourseOfStudy0.Text="";
 this.txtDEGREE0.Text="";
 this.txtLEVEL1.Text="";
 this.cmdStudentOrGraduate2.Text="";
 this.txtACADEMICINSTITUTION2.Text="";
 this.txtCourseOfStudy2.Text="";
 this.txtDEGREE2.Text="";
 this.txtLEVEL200.Text="";
 this.cmdStudentOrGraduate3.Text="";
 this.txtACADEMICINSTITUTION3.Text="";
 this.txtCourseOfStudy3.Text="";
 this.txtDEGREE3.Text="";
 this.txtLEVEL300.Text="";

        }


        private void btnSave_Click_1(object sender, EventArgs e)
        {

            String strFirstname = this.txtFIRSTNAME.Text;
            String strMiddlename = this.txtMIDDLENAME.Text;
            String strLastname = this.txtSURNAME.Text;
            String strGender = this.cmbGENDER.Text;
            String strMaritalStatus = this.cmbMARITALSTATUS.Text;
            String strGenotype = this.cmbGENOTYPE.Text;
            String strDateOfBirth = this.dtpDATEOFBIRTH.Value.ToString();
            String strBloodGroup = this.cmbBLOODGROUP.Text;
            String strStreet1 = this.txtSTREET1.Text;
            String strStreet2 = this.txtSTREET2.Text;
            String strLGACounty = this.txtLGACounty.Text;
            String strState = this.txtSTATE1.Text;
            String strCountry = this.txtCOUNTRY1.Text;
            String strTiteCardNo = this.txtTITHECARDNUMBER.Text;
            String strMobileNumber1 = this.txtMOBILENUMBER1.Text;
            String strMobileNumber2 = this.txtMOBILENUMBER2.Text;
            String strMobileNumber3 = this.txtMOBILENUMBER3.Text;
            String strMobileNumber4 = this.txtMOBILENUMBER4.Text;
            String strSpouseMobileNumber1 = this.txtSPOUSEMOBILENUMBER1.Text;
            String strSpouseMobileNumber2 = this.txtSPOUSEMOBILENUMBER2.Text;
            String strAreYouBornAgain = this.cmbAREYOUBORNAGAIN.Text;
            String strAreYouBaptizedByImmersion = this.cmbAREYOUBAPTIZEDBYIMMERSION.Text;
            String strAreYouBaptizedByHolySpirit = this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Text;
            String strEmploymentStatus = this.cmbEMPLOYEESTATUS.Text;
            String strPlaceOfWork = this.txtPLACEOFWORK.Text;
            String strPlaceOfWorkAddress = this.txtPLACEOFWORKADDRESS.Text;
            String strPlaceOfWorkPhone = this.txtPLACEOFWORKPHONENUMBERS.Text;
            String strProfession = this.txtPLACEOFWORKPROFESSION.Text;
            String strDateJoined = this.dtpDATEJOINED.Value.ToString();
            String strHobbies = this.txtHOBBIESANDINTEREST.Text;
            String strSpecialSkills = this.txtSPECIALSKILLS.Text;
            String strSpiritualGifts = this.txtSPIRITUALGIFTS.Text;
            String strPreferredGroup = this.cmdPREFERREDGROUP.Text;
            String strReason = this.txtREASON.Text;
            String strStudentOrGraduate1 = this.cmdStudentOrGraduate1.Text;
            String strInstitustion1 = this.txtACADEMICINSTITUTION1.Text;
            String strCourseOfStudy1 = this.txtCourseOfStudy0.Text;
            String strDegree1 = this.txtDEGREE0.Text;
            String strLevel1 = this.txtLEVEL1.Text;
            String strStudentOrGraduate2 = this.cmdStudentOrGraduate2.Text;
            String strInstitustion2 = this.txtACADEMICINSTITUTION2.Text;
            String strCourseOfStudy2 = this.txtCourseOfStudy2.Text;
            String strDegree2 = this.txtDEGREE2.Text;
            String strLevel2 = this.txtLEVEL200.Text;
            String strStudentOrGraduate3 = this.cmdStudentOrGraduate3.Text;
            String strInstitustion3 = this.txtACADEMICINSTITUTION3.Text;
            String strCourseOfStudy3 = this.txtCourseOfStudy3.Text;
            String strDegree3 = this.txtDEGREE3.Text;
            String strLevel3 = this.txtLEVEL300.Text;



         
////             strFirstname
////strLastname
////strMobileNumber1
////strGender
////strMaritalStatus
////strStreet1
////strStreet2
////strLGACounty
////strState
////strCountry
////strAreYouBornAgain
////strAreYouBaptizedByImmersion
////strAreYouBaptizedByHolySpirit 


            if (strFirstname.Trim().Length == 0)
            {
                this.txtFIRSTNAME.ForeColor = Color.Green;
                this.txtFIRSTNAME.BackColor = Color.Ivory;
                MessageBox.Show("FirstName Cant Be Empty");
                this.txtFIRSTNAME.Focus();
                return;
            }
            if (strLastname.Trim().Length == 0)
            {
                this.txtSURNAME.ForeColor = Color.Green;
                this.txtSURNAME.BackColor = Color.Ivory;
                MessageBox.Show("SurnName Cant Be Empty");
                this.txtSURNAME.Focus();
                return;
            }
            if (strMobileNumber1.Trim().Length == 0)
            {
                this.txtMOBILENUMBER1.ForeColor = Color.Green;
                this.txtMOBILENUMBER1.BackColor = Color.Ivory;
                MessageBox.Show("MobileNumber1 Cant Be Empty");
                this.txtMOBILENUMBER1.Focus();
                return;
            }
            if (strGender.Trim().Length == 0)
            {
                this.cmbGENDER.ForeColor = Color.Green;
                this.cmbGENDER.BackColor = Color.Ivory;
                MessageBox.Show("Select The GENDER ");
                this.cmbGENDER.Focus();
                return;
            }
            if (strMaritalStatus.Trim().Length == 0)
            {
                this.cmbMARITALSTATUS.ForeColor = Color.Green;
                this.cmbMARITALSTATUS.BackColor = Color.Ivory;
                MessageBox.Show("Select The MARITALSTAUS ");
                this.cmbMARITALSTATUS.Focus();
                return;
            }
            if (strStreet1.Trim().Length == 0)
            {
                this.txtSTREET1.ForeColor = Color.Green;
                this.txtSTREET1.BackColor = Color.Ivory;
                MessageBox.Show("Street Cant Be Empty");
                this.txtSTREET1.Focus();
                return;
            }
            ////if (strStreet2.Trim().Length == 0)
            ////{
            ////    this.txtSTREET2.ForeColor = Color.Green;
            ////    this.txtSTREET2.BackColor = Color.Ivory;
            ////    this.txtSTREET2.Focus();
            ////}
            if (strLGACounty.Trim().Length == 0)
            {
                this.txtLGACounty.ForeColor = Color.Green;
                this.txtLGACounty.BackColor = Color.Ivory;
                MessageBox.Show("LGA/County  Cant Be Empty");
                this.txtLGACounty.Focus();
                return;
            }
            if (strState.Trim().Length == 0)
            {
                this.txtSTATE1.ForeColor = Color.Green;
                this.txtSTATE1.BackColor = Color.Ivory;
                MessageBox.Show("State  Cant Be Empty");
                this.txtSTATE1.Focus();
                return;
            }

            if (strCountry.Trim().Length == 0)
            {
                this.txtCOUNTRY1.ForeColor = Color.Green;
                this.txtCOUNTRY1.BackColor = Color.Ivory;
                MessageBox.Show("Country  Cant Be Empty");
                this.txtCOUNTRY1.Focus();
                return;
            }

            if (strAreYouBornAgain.Trim().Length == 0)
            {
                this.cmbAREYOUBORNAGAIN.ForeColor = Color.Green;
                this.cmbAREYOUBORNAGAIN.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBORNAGAIN.Focus();
                return;
            }
            if (strAreYouBaptizedByImmersion.Trim().Length == 0)
            {
                this.cmbAREYOUBAPTIZEDBYIMMERSION.ForeColor = Color.Green;
                this.cmbAREYOUBAPTIZEDBYIMMERSION.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBAPTIZEDBYIMMERSION.Focus();
                return;
            }
            if (strAreYouBaptizedByHolySpirit.Trim().Length == 0)
            {
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.ForeColor = Color.Green;
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Focus();
                return;
            }





            String ssql = " INSERT INTO ChurchMembers(Firstname, Middlename, Lastname, Gender, MaritalStatus,  ";
            ssql = ssql + " Genotype, DateOfBirth, BloodGroup, Street1, Street2, LGACounty, State, Country, TiteCardNo, ";
            ssql = ssql + " MobileNumber1, MobileNumber2, MobileNumber3, MobileNumber4, SpouseMobileNumber1, SpouseMobileNumber2, ";
            ssql = ssql + " AreYouBornAgain, AreYouBaptizedByImmersion, AreYouBaptizedByHolySpirit, EmploymentStatus, PlaceOfWork,  ";
            ssql = ssql + " PlaceOfWorkAddress, PlaceOfWorkPhone, Profession, DateJoined, Hobbies, SpecialSkills, SpiritualGifts, ";
            ssql = ssql + " PreferredGroup, Reason, StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,  ";
            ssql = ssql + " StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2, StudentOrGraduate3, Institustion3,  ";
            ssql = ssql + " CourseOfStudy3, Degree3, Level3) ";
            ssql = ssql + " VALUES( ";
            ssql = ssql + " '" + strFirstname.Replace("'", " ") + "'";
            ssql = ssql + ",'" + strMiddlename.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLastname.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strGender.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMaritalStatus.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strGenotype.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDateOfBirth + "'";
            ssql = ssql + ",'" + strBloodGroup.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStreet1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStreet2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLGACounty.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strState.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCountry.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strTiteCardNo.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber4.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strSpouseMobileNumber1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strSpouseMobileNumber2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strAreYouBornAgain.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strAreYouBaptizedByImmersion.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strAreYouBaptizedByHolySpirit.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strEmploymentStatus.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPlaceOfWork.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPlaceOfWorkAddress.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPlaceOfWorkPhone.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strProfession.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDateJoined + "'";
            ssql = ssql + ",'" + strHobbies.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strSpecialSkills.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strSpiritualGifts.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPreferredGroup.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strReason.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStudentOrGraduate1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strInstitustion1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCourseOfStudy1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDegree1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLevel1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStudentOrGraduate2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strInstitustion2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCourseOfStudy2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDegree2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLevel2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStudentOrGraduate3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strInstitustion3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCourseOfStudy3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDegree3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLevel3.Replace("'", " ").Trim() + "'";
            ssql = ssql + " )  "; 
            
            
            
            
            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                       "password=;server=localhost;" +
                                       "Trusted_Connection=yes;" +
                                       "database=CHurch; " +
                                       "connection timeout=30");

            try
            {
                DialogResult bb = new DialogResult();
                bb=MessageBox.Show("Do You wanT to save this record?", "", MessageBoxButtons.OKCancel);
                if (bb== DialogResult.OK)
                {
                    myConnection.Open();
                    SqlCommand CMD = new SqlCommand();
                    CMD.CommandText = ssql;
                    CMD.Connection = myConnection;
                    int numrowsinserted = CMD.ExecuteNonQuery();
                    MessageBox.Show("Successfully Created");

                    ClearFields();

                    //close connection
                    CMD.Dispose();
                    myConnection.Close();
                }




            }
            catch (Exception e1)
            {
                Console.WriteLine(e1.ToString());
                MessageBox.Show("RECORD NOT CREATED!!!! Reason:" + e1.Message.ToString());
            }
        }

        private void txtMOBILENUMBER1_KeyPress(object sender, KeyEventArgs e)
        {
           
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void txtSTREET1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void txtCOUNTRY1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                    "password=;server=localhost;" +
                                    "Trusted_Connection=yes;" +
                                    "database=CHurch; " +
                                    "connection timeout=30");

            myConnection.Open();
            SqlCommand sc = new SqlCommand(" select distinct state from  Country  where country ='" + txtCOUNTRY1.SelectedValue.ToString().Trim()+"'", myConnection);
            SqlDataReader reader = sc.ExecuteReader();
            DataTable dt = new DataTable();
                 dt.Columns.Add("state", typeof(string));
            dt.Load(reader);
            txtSTATE1.ValueMember = "state";
            txtSTATE1.DisplayMember = "state";
            txtSTATE1.DataSource = dt;
            
            reader.Close();
            sc.Dispose();
            myConnection.Close();
        }

        private void txtSTATE1_SelectedIndexChanged(object sender, EventArgs e)
        {

            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                    "password=;server=localhost;" +
                                    "Trusted_Connection=yes;" +
                                    "database=CHurch; " +
                                    "connection timeout=30");

            myConnection.Open();
           String ssql=" select distinct  lga from  Country    ";
ssql=ssql+ "  where country  ='" + txtCOUNTRY1.SelectedValue.ToString().Trim() + "'";
ssql=ssql+ "  AND state  ='" + txtSTATE1.SelectedValue.ToString().Trim() + "'";
SqlCommand sc = new SqlCommand(ssql, myConnection);
            SqlDataReader reader = sc.ExecuteReader();
            DataTable dt = new DataTable();
 
            dt.Columns.Add("lga", typeof(string));
            dt.Load(reader);
            txtLGACounty.ValueMember = "lga";
            txtLGACounty.DisplayMember = "lga";
            txtLGACounty.DataSource = dt;

            reader.Close();
            sc.Dispose();
            myConnection.Close();
        }

        private void txtFIRSTNAME_TextChanged(object sender, EventArgs e)
        {


           




        }

        private void txtFIRSTNAME_Leave(object sender, EventArgs e)
        {
            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                    "password=;server=localhost;" +
                                    "Trusted_Connection=yes;" +
                                    "database=CHurch; " +
                                    "connection timeout=30");

            myConnection.Open();
            SqlCommand sc = new SqlCommand(" select distinct country  from  Country ", myConnection);
            SqlDataReader reader = sc.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("country", typeof(string));
            dt.Load(reader);
            txtCOUNTRY1.ValueMember = "country";
            txtCOUNTRY1.DisplayMember = "country";
            txtCOUNTRY1.DataSource = dt;

            reader.Close();
            sc.Dispose();
            myConnection.Close();
        }

      

        private void btnSearch_Click(object sender, EventArgs e)
        {

//////////SELECT Member_id ,'SELF', Member_id, ltrim(Firstname), Middlename, ltrim(Lastname), Gender, Genotype,
////////// DateOfBirth, BloodGroup, TiteCardNo,
////////// MobileNumber1, MobileNumber2, MobileNumber3, MobileNumber4, 
////////// AreYouBornAgain, AreYouBaptizedByImmersion, 
//////////AreYouBaptizedByHolySpirit, EmploymentStatus, Profession, DateJoined, 
//////////emailaddress1, emailaddress2, emailaddress3 
//////////FROM ChurchMembers
//////////union 
//////////SELECT Dependant_Member_id, Relationship, Member_id, ltrim(Firstname), 
//////////Middlename, ltrim(Lastname), Gender, Genotype, DateOfBirth, 
//////////BloodGroup, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3, 
//////////MobileNumber4, AreYouBornAgain, AreYouBaptizedByImmersion, 
//////////AreYouBaptizedByHolySpirit, EmploymentStatus, Profession, DateJoined,
 
//////////emailaddress1, emailaddress2, emailaddress3 FROM Dependant

//////////order by 1


            String  ssql="SELECT Member_id, Firstname, Middlename, Lastname, Gender, MaritalStatus,  ";
ssql=ssql + "  Genotype, DateOfBirth, BloodGroup, Street1, Street2, LGACounty,  ";
ssql=ssql + "  State, Country, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,   ";
ssql=ssql + "  MobileNumber4, SpouseMobileNumber1, SpouseMobileNumber2, AreYouBornAgain,  ";
ssql=ssql + "  AreYouBaptizedByImmersion, AreYouBaptizedByHolySpirit, EmploymentStatus,   ";
ssql=ssql + "  PlaceOfWork, PlaceOfWorkAddress, PlaceOfWorkPhone, Profession,  ";
ssql=ssql + "  DateJoined, Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup,   ";
ssql=ssql + "  Reason, StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,  ";
ssql=ssql + "  StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,  ";
ssql=ssql + "  StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,  ";
ssql=ssql + "  emailaddress1, emailaddress2, emailaddress3   ";

ssql=ssql + "  FROM ChurchMembers  ";

ssql=ssql + "  where 1=1  ";

String fieldname = cmbField1.Text.ToString().Trim();
String assign = this.cmbAssign1.Text.ToString().Trim();
String myvalue = this.txtQryValue1.Text.ToString().Trim();
if (fieldname.Length > 0 && assign.Length > 0 && myvalue.Length > 0)
{
    if (assign == "LIKE")
    {
        ssql = ssql + "  and   " + fieldname + " " + assign + " '" + "%" + myvalue + "%'";

    }
    if (assign == "=")
    {
        ssql = ssql + "  and   " + fieldname + " " + assign + " " + "'" + myvalue + "'";

    }
}

String fieldname1 = cmbField2.Text.ToString().Trim();
String assign1 = cmbAssign2.Text.ToString().Trim();
String myvalue1 = this.txtQryValue2.Text.ToString().Trim();
String myConjuction = this.cmbConjunction2.Text.ToString().Trim();
if (fieldname1.Length > 0 && assign1.Length > 0 && myvalue1.Length > 0 && myConjuction.Length > 0)
{
    if (assign == "LIKE")
    {
        ssql = ssql + "  " + myConjuction + "   " + fieldname1 + " " + assign1 + " '" + "%" + myvalue1 + "%'";

    }
    if (assign == "=")
    {
        ssql = ssql + "  " + myConjuction + "    " + fieldname1 + " " + assign1 + " " + "'" + myvalue1 + "'";

    }
}

SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                    "password=;server=localhost;" +
                                    "Trusted_Connection=yes;" +
                                    "database=CHurch; " +
                                    "connection timeout=30");

myConnection.Open();
SqlCommand sc = new SqlCommand(ssql, myConnection);
SqlDataReader reader = sc.ExecuteReader();
DataTable dt = new DataTable();
dt.Load(reader);

dataGridView1.DataSource = dt;

reader.Close();
sc.Dispose();
myConnection.Close();






        }

        private void label81_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

            String strFirstname = this.txtFIRSTNAME.Text;
            String strMiddlename = this.txtMIDDLENAME.Text;
            String strLastname = this.txtSURNAME.Text;
            String strGender = this.cmbGENDER.Text;
            String strMaritalStatus = this.cmbMARITALSTATUS.Text;
            String strGenotype = this.cmbGENOTYPE.Text;
            String strDateOfBirth = this.dtpDATEOFBIRTH.Value.ToString();
            String strBloodGroup = this.cmbBLOODGROUP.Text;
            String strStreet1 = this.txtSTREET1.Text;
            String strStreet2 = this.txtSTREET2.Text;
            String strLGACounty = this.txtLGACounty.Text;
            String strState = this.txtSTATE1.Text;
            String strCountry = this.txtCOUNTRY1.Text;
            String strTiteCardNo = this.txtTITHECARDNUMBER.Text;
            String strMobileNumber1 = this.txtMOBILENUMBER1.Text;
            String strMobileNumber2 = this.txtMOBILENUMBER2.Text;
            String strMobileNumber3 = this.txtMOBILENUMBER3.Text;
            String strMobileNumber4 = this.txtMOBILENUMBER4.Text;
            String strSpouseMobileNumber1 = this.txtSPOUSEMOBILENUMBER1.Text;
            String strSpouseMobileNumber2 = this.txtSPOUSEMOBILENUMBER2.Text;
            String strAreYouBornAgain = this.cmbAREYOUBORNAGAIN.Text;
            String strAreYouBaptizedByImmersion = this.cmbAREYOUBAPTIZEDBYIMMERSION.Text;
            String strAreYouBaptizedByHolySpirit = this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Text;
            String strEmploymentStatus = this.cmbEMPLOYEESTATUS.Text;
            String strPlaceOfWork = this.txtPLACEOFWORK.Text;
            String strPlaceOfWorkAddress = this.txtPLACEOFWORKADDRESS.Text;
            String strPlaceOfWorkPhone = this.txtPLACEOFWORKPHONENUMBERS.Text;
            String strProfession = this.txtPLACEOFWORKPROFESSION.Text;
            String strDateJoined = this.dtpDATEJOINED.Value.ToString();
            String strHobbies = this.txtHOBBIESANDINTEREST.Text;
            String strSpecialSkills = this.txtSPECIALSKILLS.Text;
            String strSpiritualGifts = this.txtSPIRITUALGIFTS.Text;
            String strPreferredGroup = this.cmdPREFERREDGROUP.Text;
            String strReason = this.txtREASON.Text;
            String strStudentOrGraduate1 = this.cmdStudentOrGraduate1.Text;
            String strInstitustion1 = this.txtACADEMICINSTITUTION1.Text;
            String strCourseOfStudy1 = this.txtCourseOfStudy0.Text;
            String strDegree1 = this.txtDEGREE0.Text;
            String strLevel1 = this.txtLEVEL1.Text;
            String strStudentOrGraduate2 = this.cmdStudentOrGraduate2.Text;
            String strInstitustion2 = this.txtACADEMICINSTITUTION2.Text;
            String strCourseOfStudy2 = this.txtCourseOfStudy2.Text;
            String strDegree2 = this.txtDEGREE2.Text;
            String strLevel2 = this.txtLEVEL200.Text;
            String strStudentOrGraduate3 = this.cmdStudentOrGraduate3.Text;
            String strInstitustion3 = this.txtACADEMICINSTITUTION3.Text;
            String strCourseOfStudy3 = this.txtCourseOfStudy3.Text;
            String strDegree3 = this.txtDEGREE3.Text;
            String strLevel3 = this.txtLEVEL300.Text;




            ////             strFirstname
            ////strLastname
            ////strMobileNumber1
            ////strGender
            ////strMaritalStatus
            ////strStreet1
            ////strStreet2
            ////strLGACounty
            ////strState
            ////strCountry
            ////strAreYouBornAgain
            ////strAreYouBaptizedByImmersion
            ////strAreYouBaptizedByHolySpirit 


            if (strFirstname.Trim().Length == 0)
            {
                this.txtFIRSTNAME.ForeColor = Color.Green;
                this.txtFIRSTNAME.BackColor = Color.Ivory;
                MessageBox.Show("FirstName Cant Be Empty");
                this.txtFIRSTNAME.Focus();
                return;
            }
            if (strLastname.Trim().Length == 0)
            {
                this.txtSURNAME.ForeColor = Color.Green;
                this.txtSURNAME.BackColor = Color.Ivory;
                MessageBox.Show("SurnName Cant Be Empty");
                this.txtSURNAME.Focus();
                return;
            }
            if (strMobileNumber1.Trim().Length == 0)
            {
                this.txtMOBILENUMBER1.ForeColor = Color.Green;
                this.txtMOBILENUMBER1.BackColor = Color.Ivory;
                MessageBox.Show("MobileNumber1 Cant Be Empty");
                this.txtMOBILENUMBER1.Focus();
                return;
            }
            if (strGender.Trim().Length == 0)
            {
                this.cmbGENDER.ForeColor = Color.Green;
                this.cmbGENDER.BackColor = Color.Ivory;
                MessageBox.Show("Select The GENDER ");
                this.cmbGENDER.Focus();
                return;
            }
            if (strMaritalStatus.Trim().Length == 0)
            {
                this.cmbMARITALSTATUS.ForeColor = Color.Green;
                this.cmbMARITALSTATUS.BackColor = Color.Ivory;
                MessageBox.Show("Select The MARITALSTAUS ");
                this.cmbMARITALSTATUS.Focus();
                return;
            }
            if (strStreet1.Trim().Length == 0)
            {
                this.txtSTREET1.ForeColor = Color.Green;
                this.txtSTREET1.BackColor = Color.Ivory;
                MessageBox.Show("Street Cant Be Empty");
                this.txtSTREET1.Focus();
                return;
            }
            ////if (strStreet2.Trim().Length == 0)
            ////{
            ////    this.txtSTREET2.ForeColor = Color.Green;
            ////    this.txtSTREET2.BackColor = Color.Ivory;
            ////    this.txtSTREET2.Focus();
            ////}
            if (strLGACounty.Trim().Length == 0)
            {
                this.txtLGACounty.ForeColor = Color.Green;
                this.txtLGACounty.BackColor = Color.Ivory;
                MessageBox.Show("LGA/County  Cant Be Empty");
                this.txtLGACounty.Focus();
                return;
            }
            if (strState.Trim().Length == 0)
            {
                this.txtSTATE1.ForeColor = Color.Green;
                this.txtSTATE1.BackColor = Color.Ivory;
                MessageBox.Show("State  Cant Be Empty");
                this.txtSTATE1.Focus();
                return;
            }

            if (strCountry.Trim().Length == 0)
            {
                this.txtCOUNTRY1.ForeColor = Color.Green;
                this.txtCOUNTRY1.BackColor = Color.Ivory;
                MessageBox.Show("Country  Cant Be Empty");
                this.txtCOUNTRY1.Focus();
                return;
            }

            if (strAreYouBornAgain.Trim().Length == 0)
            {
                this.cmbAREYOUBORNAGAIN.ForeColor = Color.Green;
                this.cmbAREYOUBORNAGAIN.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBORNAGAIN.Focus();
                return;
            }
            if (strAreYouBaptizedByImmersion.Trim().Length == 0)
            {
                this.cmbAREYOUBAPTIZEDBYIMMERSION.ForeColor = Color.Green;
                this.cmbAREYOUBAPTIZEDBYIMMERSION.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBAPTIZEDBYIMMERSION.Focus();
                return;
            }
            if (strAreYouBaptizedByHolySpirit.Trim().Length == 0)
            {
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.ForeColor = Color.Green;
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Focus();
                return;
            }





            String ssql = " UPDATE ChurchMembers   ";
            
            ssql = ssql + " SET  ";
            ssql = ssql + " Firstname= '" + strFirstname.Replace("'", " ") + "'";
            ssql = ssql + ", Middlename ='" + strMiddlename.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", Lastname= '" + strLastname.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", Gender ='" + strGender.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", MaritalStatus= '" + strMaritalStatus.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", Genotype = '" + strGenotype.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", DateOfBirth ='" + strDateOfBirth + "'";
            ssql = ssql + ", BloodGroup= '" + strBloodGroup.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", Street1 = '" + strStreet1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", Street2 = '" + strStreet2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", LGACounty  ='" + strLGACounty.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", State ='" + strState.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", Country ='" + strCountry.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", TiteCardNo ='" + strTiteCardNo.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", MobileNumber1='" + strMobileNumber1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", MobileNumber2='" + strMobileNumber2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", MobileNumber3 ='" + strMobileNumber3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",MobileNumber4 ='" + strMobileNumber4.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",SpouseMobileNumber1 ='" + strSpouseMobileNumber1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", SpouseMobileNumber2= '" + strSpouseMobileNumber2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", AreYouBornAgain = '" + strAreYouBornAgain.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", AreYouBaptizedByImmersion ='" + strAreYouBaptizedByImmersion.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", AreYouBaptizedByHolySpirit='" + strAreYouBaptizedByHolySpirit.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",EmploymentStatus = '" + strEmploymentStatus.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",PlaceOfWork = '" + strPlaceOfWork.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",PlaceOfWorkAddress ='" + strPlaceOfWorkAddress.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",PlaceOfWorkPhone ='" + strPlaceOfWorkPhone.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Profession= '" + strProfession.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",DateJoined='" + strDateJoined + "'";
            ssql = ssql + ",Hobbies='" + strHobbies.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",SpecialSkills='" + strSpecialSkills.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",SpiritualGifts='" + strSpiritualGifts.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",PreferredGroup='" + strPreferredGroup.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Reason='" + strReason.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",StudentOrGraduate1='" + strStudentOrGraduate1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Institustion1= '" + strInstitustion1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",CourseOfStudy1='" + strCourseOfStudy1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Degree1='" + strDegree1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Level1='" + strLevel1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",StudentOrGraduate2='" + strStudentOrGraduate2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Institustion2='" + strInstitustion2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",CourseOfStudy2='" + strCourseOfStudy2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Degree2='" + strDegree2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Level2='" + strLevel2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",StudentOrGraduate3='" + strStudentOrGraduate3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Institustion3='" + strInstitustion3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",CourseOfStudy3='" + strCourseOfStudy3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Degree3='" + strDegree3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",Level3='" + strLevel3.Replace("'", " ").Trim() + "'";
            ssql = ssql + " WHERE MEMBER_ID=  " + this.LBLMEMBERID.Text;




            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                       "password=;server=localhost;" +
                                       "Trusted_Connection=yes;" +
                                       "database=CHurch; " +
                                       "connection timeout=30");

            try
            {
                DialogResult bb = new DialogResult();
                bb = MessageBox.Show("Do You wanT to UPDATE this record?", "", MessageBoxButtons.OKCancel);
                if (bb == DialogResult.OK)
                {
                    myConnection.Open();
                    SqlCommand CMD = new SqlCommand();
                    CMD.CommandText = ssql;
                    CMD.Connection = myConnection;
                    int numrowsinserted = CMD.ExecuteNonQuery();
                    MessageBox.Show("Successfully UPDATED");

                    ClearFields();

                    //close connection
                    CMD.Dispose();
                    myConnection.Close();
                }




            }
            catch (Exception e1)
            {
                Console.WriteLine(e1.ToString());
                MessageBox.Show("RECORD NOT UPDATED!!!! Reason:" + e1.Message.ToString());
            }
        }

        private void txtTITHECARDNUMBER_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmdPREFERREDGROUP_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void populatedept(String memberid)
        {

            this.listView2.Columns.Clear();
            this.listView2.Columns.Add("DEPTCODE", 0);
            this.listView2.Columns.Add("GROUPCODE", 0);
            this.listView2.Columns.Add("DEPTNAME", 250);
            this.listView2.Columns.Add("GROUPNAME", 250);
            SqlConnection myConnectionMDG1 = new SqlConnection("user id=dbo;" +
                                        "password=;server=localhost;" +
                                        "Trusted_Connection=yes;" +
                                        "database=CHurch; " +
                                        "connection timeout=30");

            myConnectionMDG1.Open();

            String ssqlMD = "SELECT  A.DEPT_CODE,B.group_CODE, A.DEPT_NAME,   ";
            ssqlMD = ssqlMD + "  c.group_NAME   ";
            ssqlMD = ssqlMD + "FROM DEPARTMENT  A, MEMBER_DEPARTMENT B, [group] c  ";
            ssqlMD = ssqlMD + "WHERE 1=1 ";
            ssqlMD = ssqlMD + "AND A.Group_cOde =B.group_CODE  ";
            ssqlMD = ssqlMD + "AND A.DEPT_CODE =B.DEPT_CODE  ";
            ssqlMD = ssqlMD + "AND A.group_CODE =c.group_CODE  ";
          ssqlMD = ssqlMD + "AND B.MEMBER_ID = " + memberid + " ";
            ssqlMD = ssqlMD + "  ORDER BY A.group_CODE asC ";


            SqlCommand sc2 = new SqlCommand(ssqlMD, myConnectionMDG1);
            SqlDataReader reader2 = sc2.ExecuteReader();
            this.listView2.Items.Clear();
            while (reader2.Read())
            {
                string[] STR = new string[4];
                STR[0] = reader2.GetValue(0).ToString().ToUpper();
                STR[1] = reader2.GetValue(1).ToString().ToUpper();
                STR[2] = reader2.GetValue(2).ToString().ToUpper();
                STR[3] = reader2.GetValue(3).ToString().ToUpper();

                ListViewItem ll = new ListViewItem(STR);

                this.listView2.Items.Add(ll);
            }


          
            sc2.Cancel();

          
            reader2.Close();

            myConnectionMDG1.Close();

            //////////////////////////////////////////////////////////////

        
        
        
        }
        private void populatespouseinfo(String strSpouseMobileNumber1)
        {

            String ssql = "SELECT Member_id, Firstname, Middlename, Lastname, Gender, MaritalStatus,  ";
            ssql = ssql + "  Genotype, DateOfBirth, BloodGroup, Street1, Street2, LGACounty,  ";
            ssql = ssql + "  State, Country, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,   ";
            ssql = ssql + "  MobileNumber4, SpouseMobileNumber1, SpouseMobileNumber2, AreYouBornAgain,  ";
            ssql = ssql + "  AreYouBaptizedByImmersion, AreYouBaptizedByHolySpirit, EmploymentStatus,   ";
            ssql = ssql + "  PlaceOfWork, PlaceOfWorkAddress, PlaceOfWorkPhone, Profession,  ";
            ssql = ssql + "  DateJoined, Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup,   ";
            ssql = ssql + "  Reason, StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,  ";
            ssql = ssql + "  StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,  ";
            ssql = ssql + "  StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,  ";
            ssql = ssql + "  emailaddress1, emailaddress2, emailaddress3   ";

            ssql = ssql + "  FROM ChurchMembers  ";

            ssql = ssql + "  where ltrim(rtrim(MobileNumber1)) =  '" + strSpouseMobileNumber1.Trim() + "'";



            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                                "password=;server=localhost;" +
                                                "Trusted_Connection=yes;" +
                                                "database=CHurch; " +
                                                "connection timeout=30");

            myConnection.Open();
            SqlCommand sc = new SqlCommand(ssql, myConnection);
            SqlDataReader reader = sc.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);

            dataGridView2.DataSource = dt;

            reader.Close();
            sc.Dispose();
            myConnection.Close();

        }

        private void populatespouseinfo2(String strSpouseMobileNumber1)
        {

            String ssql = "SELECT Member_id, Firstname, Middlename, Lastname, Gender, MaritalStatus,  ";
            ssql = ssql + "  Genotype, DateOfBirth, BloodGroup, Street1, Street2, LGACounty,  ";
            ssql = ssql + "  State, Country, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,   ";
            ssql = ssql + "  MobileNumber4, SpouseMobileNumber1, SpouseMobileNumber2, AreYouBornAgain,  ";
            ssql = ssql + "  AreYouBaptizedByImmersion, AreYouBaptizedByHolySpirit, EmploymentStatus,   ";
            ssql = ssql + "  PlaceOfWork, PlaceOfWorkAddress, PlaceOfWorkPhone, Profession,  ";
            ssql = ssql + "  DateJoined, Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup,   ";
            ssql = ssql + "  Reason, StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,  ";
            ssql = ssql + "  StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,  ";
            ssql = ssql + "  StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,  ";
            ssql = ssql + "  emailaddress1, emailaddress2, emailaddress3   ";

            ssql = ssql + "  FROM ChurchMembers  ";

            ssql = ssql + "  where ltrim(rtrim(MobileNumber2)) =  '" + strSpouseMobileNumber1.Trim() + "'";



            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                                "password=;server=localhost;" +
                                                "Trusted_Connection=yes;" +
                                                "database=CHurch; " +
                                                "connection timeout=30");

            myConnection.Open();
            SqlCommand sc = new SqlCommand(ssql, myConnection);
            SqlDataReader reader = sc.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);

            dataGridView2.DataSource = dt;

            reader.Close();
            sc.Dispose();
            myConnection.Close();

        }


        //////private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //////{
        //////    int selectrowindex = e.RowIndex;
        //////    int index = dataGridView1.CurrentCell.RowIndex;
        //////    this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


        //////    DataGridViewRow rrow = dataGridView1.Rows[selectrowindex];


        //////    this.LBLMEMBERID.Text = rrow.Cells[0].Value.ToString().PadLeft(10, '0');
        //////    this.txtFIRSTNAME.Text = rrow.Cells[1].Value.ToString();
        //////    this.txtMIDDLENAME.Text = rrow.Cells[2].Value.ToString();
        //////    this.txtSURNAME.Text = rrow.Cells[3].Value.ToString();
        //////    this.cmbGENDER.Text = rrow.Cells[4].Value.ToString();
        //////    this.cmbMARITALSTATUS.Text = rrow.Cells[5].Value.ToString();
        //////    this.cmbGENOTYPE.Text = rrow.Cells[6].Value.ToString();
        //////    this.dtpDATEOFBIRTH.Value = (DateTime)rrow.Cells[7].Value;
        //////    this.cmbBLOODGROUP.Text = rrow.Cells[8].Value.ToString();
        //////    this.txtSTREET1.Text = rrow.Cells[9].Value.ToString();
        //////    this.txtSTREET2.Text = rrow.Cells[10].Value.ToString();
        //////    this.txtLGACounty.Text = rrow.Cells[11].Value.ToString();
        //////    this.txtSTATE1.Text = rrow.Cells[12].Value.ToString();
        //////    this.txtCOUNTRY1.Text = rrow.Cells[13].Value.ToString();
        //////    this.txtTITHECARDNUMBER.Text = rrow.Cells[14].Value.ToString();
        //////    this.txtMOBILENUMBER1.Text = rrow.Cells[15].Value.ToString();
        //////    this.txtMOBILENUMBER2.Text = rrow.Cells[16].Value.ToString();
        //////    this.txtMOBILENUMBER3.Text = rrow.Cells[17].Value.ToString();
        //////    this.txtMOBILENUMBER4.Text = rrow.Cells[18].Value.ToString();
        //////    this.txtSPOUSEMOBILENUMBER1.Text = rrow.Cells[19].Value.ToString();
        //////    this.txtSPOUSEMOBILENUMBER2.Text = rrow.Cells[20].Value.ToString();
        //////    this.cmbAREYOUBORNAGAIN.Text = rrow.Cells[21].Value.ToString();
        //////    this.cmbAREYOUBAPTIZEDBYIMMERSION.Text = rrow.Cells[22].Value.ToString();
        //////    this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Text = rrow.Cells[23].Value.ToString();
        //////    this.cmbEMPLOYEESTATUS.Text = rrow.Cells[24].Value.ToString();
        //////    this.txtPLACEOFWORK.Text = rrow.Cells[25].Value.ToString();
        //////    this.txtPLACEOFWORKADDRESS.Text = rrow.Cells[26].Value.ToString();
        //////    this.txtPLACEOFWORKPHONENUMBERS.Text = rrow.Cells[27].Value.ToString();
        //////    this.txtPLACEOFWORKPROFESSION.Text = rrow.Cells[28].Value.ToString();
        //////    this.dtpDATEJOINED.Value = (DateTime)rrow.Cells[29].Value;
        //////    this.txtHOBBIESANDINTEREST.Text = rrow.Cells[30].Value.ToString();
        //////    this.txtSPECIALSKILLS.Text = rrow.Cells[31].Value.ToString();
        //////    this.txtSPIRITUALGIFTS.Text = rrow.Cells[32].Value.ToString();
        //////    this.cmdPREFERREDGROUP.Text = rrow.Cells[33].Value.ToString();
        //////    this.txtREASON.Text = rrow.Cells[34].Value.ToString();
        //////    this.cmdStudentOrGraduate1.Text = rrow.Cells[35].Value.ToString();
        //////    this.txtACADEMICINSTITUTION1.Text = rrow.Cells[36].Value.ToString();
        //////    this.txtCourseOfStudy0.Text = rrow.Cells[37].Value.ToString();
        //////    this.txtDEGREE0.Text = rrow.Cells[38].Value.ToString();
        //////    this.txtLEVEL1.Text = rrow.Cells[39].Value.ToString();
        //////    this.cmdStudentOrGraduate2.Text = rrow.Cells[40].Value.ToString();
        //////    this.txtACADEMICINSTITUTION2.Text = rrow.Cells[41].Value.ToString();
        //////    this.txtCourseOfStudy2.Text = rrow.Cells[42].Value.ToString();
        //////    this.txtDEGREE2.Text = rrow.Cells[43].Value.ToString();
        //////    this.txtLEVEL200.Text = rrow.Cells[44].Value.ToString();
        //////    this.cmdStudentOrGraduate3.Text = rrow.Cells[45].Value.ToString();
        //////    this.txtACADEMICINSTITUTION3.Text = rrow.Cells[46].Value.ToString();
        //////    this.txtCourseOfStudy3.Text = rrow.Cells[47].Value.ToString();
        //////    this.txtDEGREE3.Text = rrow.Cells[48].Value.ToString();
        //////    this.txtLEVEL300.Text = rrow.Cells[49].Value.ToString();


        //////    String sqlDependant = "  SELECT Dependant_Member_id, Relationship, Member_id, Firstname,    ";
        //////    sqlDependant = sqlDependant + " Middlename, Lastname, Gender, Genotype, DateOfBirth,     ";
        //////    sqlDependant = sqlDependant + " BloodGroup, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,     ";
        //////    sqlDependant = sqlDependant + " MobileNumber4, AreYouBornAgain, AreYouBaptizedByImmersion,     ";
        //////    sqlDependant = sqlDependant + " AreYouBaptizedByHolySpirit, EmploymentStatus, PlaceOfWork,     ";
        //////    sqlDependant = sqlDependant + " PlaceOfWorkAddress, PlaceOfWorkPhone, Profession, DateJoined,    ";
        //////    sqlDependant = sqlDependant + "  Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup, Reason,    ";
        //////    sqlDependant = sqlDependant + " StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,     ";
        //////    sqlDependant = sqlDependant + " StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,     ";
        //////    sqlDependant = sqlDependant + " StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,     ";
        //////    sqlDependant = sqlDependant + " emailaddress1, emailaddress2, emailaddress3 FROM Dependant    ";
        //////    sqlDependant = sqlDependant + " where  Member_id = " + rrow.Cells[0].Value.ToString();


        //////    SqlConnection myConnection = new SqlConnection("user id=dbo;" +
        //////                            "password=;server=localhost;" +
        //////                            "Trusted_Connection=yes;" +
        //////                            "database=CHurch; " +
        //////                            "connection timeout=30");

        //////    myConnection.Open();
        //////    SqlCommand sc = new SqlCommand(sqlDependant, myConnection);
        //////    SqlDataReader reader = sc.ExecuteReader();
        //////    DataTable dt = new DataTable();
        //////    dt.Load(reader);

        //////    this.dataridDependants.DataSource = dt;

        //////    reader.Close();
        //////    sc.Dispose();
        //////    myConnection.Close();

        //////    populatedept(rrow.Cells[0].Value.ToString());




        //////}

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectrowindex = e.RowIndex;
            int index = dataGridView1.CurrentCell.RowIndex;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


            DataGridViewRow rrow = dataGridView1.Rows[selectrowindex];
         

         
            this.LBLMEMBERID.Text = rrow.Cells[0].Value.ToString().PadLeft(10, '0');
            this.txtFIRSTNAME.Text = rrow.Cells[1].Value.ToString();
            this.txtMIDDLENAME.Text = rrow.Cells[2].Value.ToString();
            this.txtSURNAME.Text= rrow.Cells[3].Value.ToString();
            this.cmbGENDER.Text = rrow.Cells[4].Value.ToString();
            this.cmbMARITALSTATUS.Text = rrow.Cells[5].Value.ToString();
            this.cmbGENOTYPE.Text = rrow.Cells[6].Value.ToString();
            this.dtpDATEOFBIRTH.Value= (DateTime)rrow.Cells[7].Value;
            this.cmbBLOODGROUP.Text = rrow.Cells[8].Value.ToString();
            this.txtSTREET1.Text = rrow.Cells[9].Value.ToString();
            this.txtSTREET2.Text = rrow.Cells[10].Value.ToString();
            this.txtLGACounty.Text = rrow.Cells[11].Value.ToString();
            this.txtSTATE1.Text = rrow.Cells[12].Value.ToString();
            this.txtCOUNTRY1.Text = rrow.Cells[13].Value.ToString();
            this.txtTITHECARDNUMBER.Text = rrow.Cells[14].Value.ToString();
            this.txtMOBILENUMBER1.Text = rrow.Cells[15].Value.ToString();
            this.txtMOBILENUMBER2.Text = rrow.Cells[16].Value.ToString();
            this.txtMOBILENUMBER3.Text = rrow.Cells[17].Value.ToString();
            this.txtMOBILENUMBER4.Text = rrow.Cells[18].Value.ToString();
            this.txtSPOUSEMOBILENUMBER1.Text = rrow.Cells[19].Value.ToString();
            ////Populate the spousinfo  the first number of the spouse takes precedence!!!!
            if (rrow.Cells[19].Value.ToString().Trim().Length > 0)
            {
                populatespouseinfo(rrow.Cells[19].Value.ToString());
            }
            else
            {
                if (rrow.Cells[20].Value.ToString().Trim().Length > 0)
                {
                    populatespouseinfo(rrow.Cells[20].Value.ToString());
                }
            }
            

                this.txtSPOUSEMOBILENUMBER2.Text = rrow.Cells[20].Value.ToString();
           this.cmbAREYOUBORNAGAIN.Text = rrow.Cells[21].Value.ToString();
            this.cmbAREYOUBAPTIZEDBYIMMERSION.Text = rrow.Cells[22].Value.ToString();
           this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Text = rrow.Cells[23].Value.ToString();
            this.cmbEMPLOYEESTATUS.Text = rrow.Cells[24].Value.ToString();
           this.txtPLACEOFWORK.Text = rrow.Cells[25].Value.ToString();
          this.txtPLACEOFWORKADDRESS.Text = rrow.Cells[26].Value.ToString();
            this.txtPLACEOFWORKPHONENUMBERS.Text = rrow.Cells[27].Value.ToString();
          this.txtPLACEOFWORKPROFESSION.Text = rrow.Cells[28].Value.ToString();
          this.dtpDATEJOINED.Value = (DateTime)rrow.Cells[29].Value;
           this.txtHOBBIESANDINTEREST.Text = rrow.Cells[30].Value.ToString();
           this.txtSPECIALSKILLS.Text = rrow.Cells[31].Value.ToString();
           this.txtSPIRITUALGIFTS.Text = rrow.Cells[32].Value.ToString();
         this.cmdPREFERREDGROUP.Text = rrow.Cells[33].Value.ToString();
          this.txtREASON.Text = rrow.Cells[34].Value.ToString();
           this.cmdStudentOrGraduate1.Text = rrow.Cells[35].Value.ToString();
          this.txtACADEMICINSTITUTION1.Text = rrow.Cells[36].Value.ToString();
          this.txtCourseOfStudy0.Text = rrow.Cells[37].Value.ToString();
           this.txtDEGREE0.Text = rrow.Cells[38].Value.ToString();
        this.txtLEVEL1.Text = rrow.Cells[39].Value.ToString();
            this.cmdStudentOrGraduate2.Text = rrow.Cells[40].Value.ToString();
       this.txtACADEMICINSTITUTION2.Text = rrow.Cells[41].Value.ToString();
       this.txtCourseOfStudy2.Text = rrow.Cells[42].Value.ToString();
       this.txtDEGREE2.Text = rrow.Cells[43].Value.ToString();
        this.txtLEVEL200.Text = rrow.Cells[44].Value.ToString();
      this.cmdStudentOrGraduate3.Text = rrow.Cells[45].Value.ToString();
   this.txtACADEMICINSTITUTION3.Text = rrow.Cells[46].Value.ToString();
   this.txtCourseOfStudy3.Text = rrow.Cells[47].Value.ToString();
    this.txtDEGREE3.Text = rrow.Cells[48].Value.ToString();
    this.txtLEVEL300.Text= rrow.Cells[49].Value.ToString();

    String sqlDependant = "  SELECT Dependant_Member_id, Relationship, Member_id, Firstname,    ";
    sqlDependant = sqlDependant + " Middlename, Lastname, Gender, Genotype, DateOfBirth,     ";
    sqlDependant = sqlDependant + " BloodGroup, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,     ";
    sqlDependant = sqlDependant + " MobileNumber4, AreYouBornAgain, AreYouBaptizedByImmersion,     ";
    sqlDependant = sqlDependant + " AreYouBaptizedByHolySpirit, EmploymentStatus, PlaceOfWork,     ";
    sqlDependant = sqlDependant + " PlaceOfWorkAddress, PlaceOfWorkPhone, Profession, DateJoined,    ";
    sqlDependant = sqlDependant + "  Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup, Reason,    ";
    sqlDependant = sqlDependant + " StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,     ";
    sqlDependant = sqlDependant + " StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,     ";
    sqlDependant = sqlDependant + " StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,     ";
    sqlDependant = sqlDependant + " emailaddress1, emailaddress2, emailaddress3 FROM Dependant    ";
    sqlDependant = sqlDependant + " where  Member_id = " + rrow.Cells[0].Value.ToString();


    SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                            "password=;server=localhost;" +
                            "Trusted_Connection=yes;" +
                            "database=CHurch; " +
                            "connection timeout=30");

    myConnection.Open();
    SqlCommand sc = new SqlCommand(sqlDependant, myConnection);
    SqlDataReader reader = sc.ExecuteReader();
    DataTable dt = new DataTable();
    dt.Load(reader);

    this.dataridDependants.DataSource = dt;

    reader.Close();
    sc.Dispose();
    myConnection.Close();

    populatedept(rrow.Cells[0].Value.ToString());

    /////////// SET THE UPDATE  BUTTONS
    this.btnSave.Enabled = false;
    this.button2.Enabled = true;
        }

        ////private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        ////{
        ////    int selectrowindex = e.RowIndex;
        ////    int index = dataGridView1.CurrentCell.RowIndex;
        ////    this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


        ////    DataGridViewRow rrow = dataGridView1.Rows[selectrowindex];



        ////    this.LBLMEMBERID.Text = rrow.Cells[0].Value.ToString().PadLeft(10, '0');
        ////    this.txtFIRSTNAME.Text = rrow.Cells[1].Value.ToString();
        ////    this.txtMIDDLENAME.Text = rrow.Cells[2].Value.ToString();
        ////    this.txtSURNAME.Text = rrow.Cells[3].Value.ToString();
        ////    this.cmbGENDER.Text = rrow.Cells[4].Value.ToString();
        ////    this.cmbMARITALSTATUS.Text = rrow.Cells[5].Value.ToString();
        ////    this.cmbGENOTYPE.Text = rrow.Cells[6].Value.ToString();
        ////    this.dtpDATEOFBIRTH.Value = (DateTime)rrow.Cells[7].Value;
        ////    this.cmbBLOODGROUP.Text = rrow.Cells[8].Value.ToString();
        ////    this.txtSTREET1.Text = rrow.Cells[9].Value.ToString();
        ////    this.txtSTREET2.Text = rrow.Cells[10].Value.ToString();
        ////    this.txtLGACounty.Text = rrow.Cells[11].Value.ToString();
        ////    this.txtSTATE1.Text = rrow.Cells[12].Value.ToString();
        ////    this.txtCOUNTRY1.Text = rrow.Cells[13].Value.ToString();
        ////    this.txtTITHECARDNUMBER.Text = rrow.Cells[14].Value.ToString();
        ////    this.txtMOBILENUMBER1.Text = rrow.Cells[15].Value.ToString();
        ////    this.txtMOBILENUMBER2.Text = rrow.Cells[16].Value.ToString();
        ////    this.txtMOBILENUMBER3.Text = rrow.Cells[17].Value.ToString();
        ////    this.txtMOBILENUMBER4.Text = rrow.Cells[18].Value.ToString();
        ////    this.txtSPOUSEMOBILENUMBER1.Text = rrow.Cells[19].Value.ToString();
        ////    this.txtSPOUSEMOBILENUMBER2.Text = rrow.Cells[20].Value.ToString();
        ////    this.cmbAREYOUBORNAGAIN.Text = rrow.Cells[21].Value.ToString();
        ////    this.cmbAREYOUBAPTIZEDBYIMMERSION.Text = rrow.Cells[22].Value.ToString();
        ////    this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Text = rrow.Cells[23].Value.ToString();
        ////    this.cmbEMPLOYEESTATUS.Text = rrow.Cells[24].Value.ToString();
        ////    this.txtPLACEOFWORK.Text = rrow.Cells[25].Value.ToString();
        ////    this.txtPLACEOFWORKADDRESS.Text = rrow.Cells[26].Value.ToString();
        ////    this.txtPLACEOFWORKPHONENUMBERS.Text = rrow.Cells[27].Value.ToString();
        ////    this.txtPLACEOFWORKPROFESSION.Text = rrow.Cells[28].Value.ToString();
        ////    this.dtpDATEJOINED.Value = (DateTime)rrow.Cells[29].Value;
        ////    this.txtHOBBIESANDINTEREST.Text = rrow.Cells[30].Value.ToString();
        ////    this.txtSPECIALSKILLS.Text = rrow.Cells[31].Value.ToString();
        ////    this.txtSPIRITUALGIFTS.Text = rrow.Cells[32].Value.ToString();
        ////    this.cmdPREFERREDGROUP.Text = rrow.Cells[33].Value.ToString();
        ////    this.txtREASON.Text = rrow.Cells[34].Value.ToString();
        ////    this.cmdStudentOrGraduate1.Text = rrow.Cells[35].Value.ToString();
        ////    this.txtACADEMICINSTITUTION1.Text = rrow.Cells[36].Value.ToString();
        ////    this.txtCourseOfStudy0.Text = rrow.Cells[37].Value.ToString();
        ////    this.txtDEGREE0.Text = rrow.Cells[38].Value.ToString();
        ////    this.txtLEVEL1.Text = rrow.Cells[39].Value.ToString();
        ////    this.cmdStudentOrGraduate2.Text = rrow.Cells[40].Value.ToString();
        ////    this.txtACADEMICINSTITUTION2.Text = rrow.Cells[41].Value.ToString();
        ////    this.txtCourseOfStudy2.Text = rrow.Cells[42].Value.ToString();
        ////    this.txtDEGREE2.Text = rrow.Cells[43].Value.ToString();
        ////    this.txtLEVEL200.Text = rrow.Cells[44].Value.ToString();
        ////    this.cmdStudentOrGraduate3.Text = rrow.Cells[45].Value.ToString();
        ////    this.txtACADEMICINSTITUTION3.Text = rrow.Cells[46].Value.ToString();
        ////    this.txtCourseOfStudy3.Text = rrow.Cells[47].Value.ToString();
        ////    this.txtDEGREE3.Text = rrow.Cells[48].Value.ToString();
        ////    this.txtLEVEL300.Text = rrow.Cells[49].Value.ToString();

        ////    String sqlDependant = "  SELECT Dependant_Member_id, Relationship, Member_id, Firstname,    ";
        ////    sqlDependant = sqlDependant + " Middlename, Lastname, Gender, Genotype, DateOfBirth,     ";
        ////    sqlDependant = sqlDependant + " BloodGroup, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,     ";
        ////    sqlDependant = sqlDependant + " MobileNumber4, AreYouBornAgain, AreYouBaptizedByImmersion,     ";
        ////    sqlDependant = sqlDependant + " AreYouBaptizedByHolySpirit, EmploymentStatus, PlaceOfWork,     ";
        ////    sqlDependant = sqlDependant + " PlaceOfWorkAddress, PlaceOfWorkPhone, Profession, DateJoined,    ";
        ////    sqlDependant = sqlDependant + "  Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup, Reason,    ";
        ////    sqlDependant = sqlDependant + " StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,     ";
        ////    sqlDependant = sqlDependant + " StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,     ";
        ////    sqlDependant = sqlDependant + " StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,     ";
        ////    sqlDependant = sqlDependant + " emailaddress1, emailaddress2, emailaddress3 FROM Dependant    ";
        ////    sqlDependant = sqlDependant + " where  Member_id = " + rrow.Cells[0].Value.ToString();


        ////    SqlConnection myConnection = new SqlConnection("user id=dbo;" +
        ////                            "password=;server=localhost;" +
        ////                            "Trusted_Connection=yes;" +
        ////                            "database=CHurch; " +
        ////                            "connection timeout=30");

        ////    myConnection.Open();
        ////    SqlCommand sc = new SqlCommand(sqlDependant, myConnection);
        ////    SqlDataReader reader = sc.ExecuteReader();
        ////    DataTable dt = new DataTable();
        ////    dt.Load(reader);

        ////    this.dataridDependants.DataSource = dt;

        ////    reader.Close();
        ////    sc.Dispose();
        ////    myConnection.Close();


        ////}

        private void txtMOBILENUMBER1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMOBILENUMBER2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMOBILENUMBER4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && (sender as TextBox).Text.IndexOf('.') < -1)
            {
                e.Handled = true;
            }
        }

        private void txtSPOUSEMOBILENUMBER1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSPOUSEMOBILENUMBER1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && (sender as TextBox).Text.IndexOf('.') < -1)
            {
                e.Handled = true;
            }
        }

        private void txtMOBILENUMBER1_KeyPress(object sender, KeyPressEventArgs e)
        {
          
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && (sender as TextBox).Text.IndexOf('.') < -1)
            {
                e.Handled = true;
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtSURNAME_TextChanged(object sender, EventArgs e)
        {

        }
        }

  
    }