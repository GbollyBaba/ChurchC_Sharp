using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DCM
{
    public partial class Depandent : Form
    {
        public String memberid = "";
        public String relatype = "";
        public int FLAG = 1;
        public Depandent()
        {
            InitializeComponent();
            button2.Enabled = false;

            dataGridView1.Enabled = true;
            this.tabControl1.SelectedIndex = 1;

            ///populate the search fields
            ///
            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                  "password=;server=localhost;" +
                                  "Trusted_Connection=yes;" +
                                  "database=CHurch; " +
                                  "connection timeout=30");
            SqlConnection myConnection1 = new SqlConnection("user id=dbo;" +
                            "password=;server=localhost;" +
                            "Trusted_Connection=yes;" +
                            "database=CHurch; " +
                            "connection timeout=30");

            SqlConnection myConnection3 = new SqlConnection("user id=dbo;" +
                           "password=;server=localhost;" +
                           "Trusted_Connection=yes;" +
                           "database=CHurch; " +
                           "connection timeout=30");

            myConnection.Open();
            myConnection1.Open();
            String ssql = " select fieldname from MYCOLUMN  where mytablename='CHURCHMEMBERS'  ";

            SqlCommand sc = new SqlCommand(ssql, myConnection);
            SqlDataReader reader = sc.ExecuteReader();
            DataTable dt = new DataTable();

            SqlCommand sc1 = new SqlCommand(ssql, myConnection1);
            SqlDataReader reader1 = sc1.ExecuteReader();
            DataTable dt1 = new DataTable();


            dt.Columns.Add("fieldname", typeof(string));
            dt.Load(reader);


            dt1.Columns.Add("fieldname", typeof(string));
            dt1.Load(reader1);


            cmbField1.ValueMember = "fieldname";
            cmbField2.ValueMember = "fieldname";
            cmbField1.DisplayMember = "fieldname";
            cmbField2.DisplayMember = "fieldname";
            cmbField1.DataSource = dt;
            cmbField2.DataSource = dt1;


            reader.Close();
            sc.Dispose();
            myConnection.Close();

            reader1.Close();
            sc1.Dispose();
            myConnection1.Close();

            ///SELT THE ITEM TO THE FIRST RECORD IN THE DATATABLE
            cmbField1.SelectedIndex = 0;
            cmbField2.SelectedIndex = 0;
            cmbAssign1.SelectedIndex = 0;
            cmbAssign2.SelectedIndex = 0;

            SqlConnection myConnection33 = new SqlConnection("user id=dbo;" +
                                              "password=;server=localhost;" +
                                              "Trusted_Connection=yes;" +
                                              "database=CHurch; " +
                                              "connection timeout=30");

            myConnection33.Open();
            String ssql33 = " SELECT  DISTINCT [PrefferedGroup_shortname] FROM [Church].[dbo].[PrefferedGroup]   ";

            SqlCommand sc33 = new SqlCommand(ssql33, myConnection33);
            SqlDataReader reader33 = sc33.ExecuteReader();
            DataTable dt33 = new DataTable();

            dt33.Columns.Add("PrefferedGroup_shortname", typeof(string));
            dt33.Load(reader33);
            cmdPREFERREDGROUP.ValueMember = "PrefferedGroup_shortname";
            cmdPREFERREDGROUP.DisplayMember = "PrefferedGroup_shortname";
            cmdPREFERREDGROUP.DataSource = dt33;

            reader33.Close();
            sc33.Dispose();
            myConnection33.Close();

            this.listView1.Columns.Clear();




            SqlConnection myConnection11 = new SqlConnection("user id=dbo;" +
                               "password=;server=localhost;" +
                               "Trusted_Connection=yes;" +
                               "database=CHurch; " +
                               "connection timeout=30");
            comboBox3.DataSource = null;
            comboBox3.Items.Clear();
            String ssql11 = " SELECT RELATIONSHIP_TYPE FROM RELATIONSHIP where gender IN ('MALE','FEMALE') ORDER BY 1 ASC";
            myConnection11.Open();
            SqlCommand sc11 = new SqlCommand(ssql11, myConnection11);
            SqlDataReader reader11 = sc11.ExecuteReader();
            DataTable dt11 = new DataTable();
            dt11.Columns.Add("RELATIONSHIP_TYPE", typeof(string));
            dt11.Load(reader11);

            comboBox3.DisplayMember = "RELATIONSHIP_TYPE";
            comboBox3.DataSource = dt11;

            myConnection11.Close();

        }

        private void ClearFields()
        {
            this.txtFIRSTNAME.Text = "";
            this.txtMIDDLENAME.Text = "";
            this.txtSURNAME.Text = "";
            this.cmbGENDER.Text = "";
            this.cmbGENOTYPE.Text = "";
            this.dtpDATEOFBIRTH.Value = DateTime.Now;
            this.cmbBLOODGROUP.Text = "";
            this.txtTITHECARDNUMBER.Text = "";
            this.txtMOBILENUMBER1.Text = "";
            this.txtMOBILENUMBER2.Text = "";
            this.txtMOBILENUMBER3.Text = "";
            this.txtMOBILENUMBER4.Text = "";
            this.cmbAREYOUBORNAGAIN.Text = "";
            this.cmbAREYOUBAPTIZEDBYIMMERSION.Text = "";
            this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Text = "";
            this.cmbEMPLOYEESTATUS.Text = "";
            this.txtPLACEOFWORK.Text = "";
            this.txtPLACEOFWORKADDRESS.Text = "";
            this.txtPLACEOFWORKPHONENUMBERS.Text = "";
            this.txtPLACEOFWORKPROFESSION.Text = "";
            this.dtpDATEJOINED.Value = DateTime.Now;
            this.txtHOBBIESANDINTEREST.Text = "";
            this.txtSPECIALSKILLS.Text = "";
            this.txtSPIRITUALGIFTS.Text = "";
            this.cmdPREFERREDGROUP.Text = "";
            this.txtREASON.Text = "";
            this.cmdStudentOrGraduate1.Text = "";
            this.txtACADEMICINSTITUTION1.Text = "";
            this.txtCourseOfStudy0.Text = "";
            this.txtDEGREE0.Text = "";
            // this.txtLEVEL1.Text = "";
            this.cmdStudentOrGraduate2.Text = "";
            this.txtACADEMICINSTITUTION2.Text = "";
            this.txtCourseOfStudy2.Text = "";
            this.txtDEGREE2.Text = "";
            this.txtLEVEL200.Text = "";
            this.cmdStudentOrGraduate3.Text = "";
            this.txtACADEMICINSTITUTION3.Text = "";
            this.txtCourseOfStudy3.Text = "";
            this.txtDEGREE3.Text = "";
            this.txtLEVEL300.Text = "";

        }


        private void btnSave_Click_1(object sender, EventArgs e)
        {

            String strFirstname = this.txtFIRSTNAME.Text;
            String strMiddlename = this.txtMIDDLENAME.Text;
            String strLastname = this.txtSURNAME.Text;
            String strGender = this.cmbGENDER.Text;
            String strGenotype = this.cmbGENOTYPE.Text;
            String strDateOfBirth = this.dtpDATEOFBIRTH.Value.ToString();
            String strBloodGroup = this.cmbBLOODGROUP.Text;

            String strTiteCardNo = this.txtTITHECARDNUMBER.Text;
            String strMobileNumber1 = this.txtMOBILENUMBER1.Text;
            String strMobileNumber2 = this.txtMOBILENUMBER2.Text;
            String strMobileNumber3 = this.txtMOBILENUMBER3.Text;
            String strMobileNumber4 = this.txtMOBILENUMBER4.Text;
            String strAreYouBornAgain = this.cmbAREYOUBORNAGAIN.Text;
            String strAreYouBaptizedByImmersion = this.cmbAREYOUBAPTIZEDBYIMMERSION.Text;
            String strAreYouBaptizedByHolySpirit = this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Text;
            String strEmploymentStatus = this.cmbEMPLOYEESTATUS.Text;
            String strPlaceOfWork = this.txtPLACEOFWORK.Text;
            String strPlaceOfWorkAddress = this.txtPLACEOFWORKADDRESS.Text;
            String strPlaceOfWorkPhone = this.txtPLACEOFWORKPHONENUMBERS.Text;
            String strProfession = this.txtPLACEOFWORKPROFESSION.Text;
            String strDateJoined = this.dtpDATEJOINED.Value.ToString();
            String strHobbies = this.txtHOBBIESANDINTEREST.Text;
            String strSpecialSkills = this.txtSPECIALSKILLS.Text;
            String strSpiritualGifts = this.txtSPIRITUALGIFTS.Text;
            String strPreferredGroup = this.cmdPREFERREDGROUP.Text;
            String strReason = this.txtREASON.Text;
            String strStudentOrGraduate1 = this.cmdStudentOrGraduate1.Text;
            String strInstitustion1 = this.txtACADEMICINSTITUTION1.Text;
            String strCourseOfStudy1 = this.txtCourseOfStudy0.Text;
            String strDegree1 = this.txtDEGREE0.Text;
            //    String strLevel1 = this.txtLEVEL1.Text;
            String strStudentOrGraduate2 = this.cmdStudentOrGraduate2.Text;
            String strInstitustion2 = this.txtACADEMICINSTITUTION2.Text;
            String strCourseOfStudy2 = this.txtCourseOfStudy2.Text;
            String strDegree2 = this.txtDEGREE2.Text;
            String strLevel2 = this.txtLEVEL200.Text;
            String strStudentOrGraduate3 = this.cmdStudentOrGraduate3.Text;
            String strInstitustion3 = this.txtACADEMICINSTITUTION3.Text;
            String strCourseOfStudy3 = this.txtCourseOfStudy3.Text;
            String strDegree3 = this.txtDEGREE3.Text;
            String strLevel3 = this.txtLEVEL300.Text;

            if (strFirstname.Trim().Length == 0)
            {
                this.txtFIRSTNAME.ForeColor = Color.Green;
                this.txtFIRSTNAME.BackColor = Color.Ivory;
                MessageBox.Show("FirstName Cant Be Empty");
                this.txtFIRSTNAME.Focus();
                return;
            }
            if (strLastname.Trim().Length == 0)
            {
                this.txtSURNAME.ForeColor = Color.Green;
                this.txtSURNAME.BackColor = Color.Ivory;
                MessageBox.Show("SurnName Cant Be Empty");
                this.txtSURNAME.Focus();
                return;
            }
            if (strMobileNumber1.Trim().Length == 0)
            {
                this.txtMOBILENUMBER1.ForeColor = Color.Green;
                this.txtMOBILENUMBER1.BackColor = Color.Ivory;
                MessageBox.Show("MobileNumber1 Cant Be Empty");
                this.txtMOBILENUMBER1.Focus();
                return;
            }
            if (strGender.Trim().Length == 0)
            {
                this.cmbGENDER.ForeColor = Color.Green;
                this.cmbGENDER.BackColor = Color.Ivory;
                MessageBox.Show("Select The GENDER ");
                this.cmbGENDER.Focus();
                return;
            }
            if (strAreYouBornAgain.Trim().Length == 0)
            {
                this.cmbAREYOUBORNAGAIN.ForeColor = Color.Green;
                this.cmbAREYOUBORNAGAIN.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBORNAGAIN.Focus();
                return;
            }
            if (strAreYouBaptizedByImmersion.Trim().Length == 0)
            {
                this.cmbAREYOUBAPTIZEDBYIMMERSION.ForeColor = Color.Green;
                this.cmbAREYOUBAPTIZEDBYIMMERSION.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBAPTIZEDBYIMMERSION.Focus();
                return;
            }
            if (strAreYouBaptizedByHolySpirit.Trim().Length == 0)
            {
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.ForeColor = Color.Green;
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Focus();
                return;
            }





            String ssql = " INSERT INTO Dependats(Firstname, Middlename, Lastname, Gender,  ";
            ssql = ssql + " Genotype, DateOfBirth, BloodGroup, TiteCardNo, ";
            ssql = ssql + " MobileNumber1, MobileNumber2, MobileNumber3, MobileNumber4,  ";
            ssql = ssql + " AreYouBornAgain, AreYouBaptizedByImmersion, AreYouBaptizedByHolySpirit, EmploymentStatus, PlaceOfWork,  ";
            ssql = ssql + " PlaceOfWorkAddress, PlaceOfWorkPhone, Profession, DateJoined, Hobbies, SpecialSkills, SpiritualGifts, ";
            ssql = ssql + " PreferredGroup, Reason, StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,  ";
            ssql = ssql + " StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2, StudentOrGraduate3, Institustion3,  ";
            ssql = ssql + " CourseOfStudy3, Degree3, Level3) ";
            ssql = ssql + " VALUES( ";
            ssql = ssql + " '" + strFirstname.Replace("'", " ") + "'";
            ssql = ssql + ",'" + strMiddlename.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLastname.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strGender.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strGenotype.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDateOfBirth + "'";
            ssql = ssql + ",'" + strBloodGroup.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strTiteCardNo.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber4.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strAreYouBornAgain.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strAreYouBaptizedByImmersion.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strAreYouBaptizedByHolySpirit.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strEmploymentStatus.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPlaceOfWork.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPlaceOfWorkAddress.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPlaceOfWorkPhone.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strProfession.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDateJoined + "'";
            ssql = ssql + ",'" + strHobbies.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strSpecialSkills.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strSpiritualGifts.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPreferredGroup.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strReason.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStudentOrGraduate1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strInstitustion1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCourseOfStudy1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDegree1.Replace("'", " ").Trim() + "'";
            //ssql = ssql + ",'" + strLevel1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStudentOrGraduate2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strInstitustion2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCourseOfStudy2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDegree2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLevel2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStudentOrGraduate3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strInstitustion3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCourseOfStudy3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDegree3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLevel3.Replace("'", " ").Trim() + "'";
            ssql = ssql + " )  ";




            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                       "password=;server=localhost;" +
                                       "Trusted_Connection=yes;" +
                                       "database=CHurch; " +
                                       "connection timeout=30");

            try
            {
                DialogResult bb = new DialogResult();
                bb = MessageBox.Show("Do You wanT to save this record?", "", MessageBoxButtons.OKCancel);
                if (bb == DialogResult.OK)
                {
                    myConnection.Open();
                    SqlCommand CMD = new SqlCommand();
                    CMD.CommandText = ssql;
                    CMD.Connection = myConnection;
                    int numrowsinserted = CMD.ExecuteNonQuery();
                    MessageBox.Show("Successfully Created");

                    ClearFields();

                    //close connection
                    CMD.Dispose();
                    myConnection.Close();
                }




            }
            catch (Exception e1)
            {
                Console.WriteLine(e1.ToString());
                MessageBox.Show("RECORD NOT CREATED!!!! Reason:" + e1.Message.ToString());
            }
        }

        private void txtMOBILENUMBER1_KeyPress(object sender, KeyEventArgs e)
        {
            ////int k = 0;
            ////int l = 0;
            ////int m = 0;
            ////int n = 0;

            ////if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9)
            ////{
            ////    k++;
            ////}
            ////if (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)
            ////{
            ////    l++;
            ////}
            ////if (e.KeyCode == Keys.Back)
            ////{
            ////    m++;
            ////}
            ////if (e.KeyCode == Keys.Delete)
            ////{
            ////    n++;
            ////}
            ////if (k == 0)
            ////{
            ////    l = 0;
            ////    if (l == 0 )
            ////    {
            ////        MessageBox.Show("This only allows numbers!!!!!");
            ////        e.Handled = true;
            ////    }

            ////}
            ////else {
            ////    if (l == 0)
            ////    {
            ////        MessageBox.Show("This only allows numbers!!!!!");
            ////        e.Handled = true;
            ////    }
            ////   }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void txtSTREET1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }



        private void btnSearch_Click(object sender, EventArgs e)
        {

            String ssql = "SELECT Member_id, Firstname, Middlename, Lastname, Gender, MaritalStatus,  ";
            ssql = ssql + "  Genotype, DateOfBirth, BloodGroup, Street1, Street2, LGACounty,  ";
            ssql = ssql + "  State, Country, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,   ";
            ssql = ssql + "  MobileNumber4, SpouseMobileNumber1, SpouseMobileNumber2, AreYouBornAgain,  ";
            ssql = ssql + "  AreYouBaptizedByImmersion, AreYouBaptizedByHolySpirit, EmploymentStatus,   ";
            ssql = ssql + "  PlaceOfWork, PlaceOfWorkAddress, PlaceOfWorkPhone, Profession,  ";
            ssql = ssql + "  DateJoined, Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup,   ";
            ssql = ssql + "  Reason, StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,  ";
            ssql = ssql + "  StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,  ";
            ssql = ssql + "  StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,  ";
            ssql = ssql + "  emailaddress1, emailaddress2, emailaddress3   ";

            ssql = ssql + "  FROM ChurchMembers  ";

            ssql = ssql + "  where 1=1  ";

            String fieldname = cmbField1.Text.ToString().Trim();
            String assign = this.cmbAssign1.Text.ToString().Trim();
            String myvalue = this.txtQryValue1.Text.ToString().Trim();
            if (fieldname.Length > 0 && assign.Length > 0 && myvalue.Length > 0)
            {
                if (assign == "LIKE")
                {
                    ssql = ssql + "  and   " + fieldname + " " + assign + " '" + "%" + myvalue + "%'";

                }
                if (assign == "=")
                {
                    ssql = ssql + "  and   " + fieldname + " " + assign + " " + "'" + myvalue + "'";

                }
            }

            String fieldname1 = cmbField2.Text.ToString().Trim();
            String assign1 = cmbAssign2.Text.ToString().Trim();
            String myvalue1 = this.txtQryValue2.Text.ToString().Trim();
            String myConjuction = this.cmbConjunction2.Text.ToString().Trim();
            if (fieldname1.Length > 0 && assign1.Length > 0 && myvalue1.Length > 0 && myConjuction.Length > 0)
            {
                if (assign == "LIKE")
                {
                    ssql = ssql + "  " + myConjuction + "   " + fieldname1 + " " + assign1 + " '" + "%" + myvalue1 + "%'";

                }
                if (assign == "=")
                {
                    ssql = ssql + "  " + myConjuction + "    " + fieldname1 + " " + assign1 + " " + "'" + myvalue1 + "'";

                }
            }

            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                                "password=;server=localhost;" +
                                                "Trusted_Connection=yes;" +
                                                "database=CHurch; " +
                                                "connection timeout=30");

            myConnection.Open();
            SqlCommand sc = new SqlCommand(ssql, myConnection);
            SqlDataReader reader = sc.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);

            dataGridView1.DataSource = dt;

            reader.Close();
            sc.Dispose();
            myConnection.Close();






        }

        private void label81_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

           //// SqlConnection myConnectionR = new SqlConnection("user id=dbo;" +
           ////                                   "password=;server=localhost;" +
           ////                                   "Trusted_Connection=yes;" +
           ////                                   "database=CHurch; " +
           ////                                   "connection timeout=30");

           //// myConnectionR.Open();
           ////relatype = comboBox3.Text.ToString().Trim();
           //// String ssqlR = " SELECT distinct GENDER  FROM [Church].[dbo].[RELATIONSHIP] where RELATIONSHIP_TYPE ='"+relatype+"'   ";

           //// SqlCommand scR = new SqlCommand(ssqlR, myConnectionR);
           //// SqlDataReader readerR = scR.ExecuteReader();
           //// DataTable dtR  = new DataTable();

           //// dtR.Columns.Add("GENDER", typeof(string));
           //// dtR.Load(readerR);
           //// cmbGENDER.ValueMember = "GENDER";
           //// cmbGENDER.DisplayMember = "GENDER";
           //// cmbGENDER.DataSource = dtR;

           //// readerR.Close();
           //// scR.Dispose();
           //// myConnectionR.Close();



           //// dataGridView1.Enabled = false;
           //// this.tabControl1.SelectedIndex = 0;





        }

        private void button2_Click(object sender, EventArgs e)
        {

        }


        private void button3_Click_1(object sender, EventArgs e)
        {

        }

     


        private void btnSearch_Click_1(object sender, EventArgs e)
        {
         ///  comboBox3.DataSource = null;
       ///     this.comboBox3.Items.Clear();
            String genderforsearch = cmbMyGender.Text;

            if (genderforsearch.Trim().Length > 0)
            {

                String ssql = "SELECT Member_id, Firstname, Middlename, Lastname, Gender, MaritalStatus,  ";
                ssql = ssql + "  Genotype, DateOfBirth, BloodGroup, Street1, Street2, LGACounty,  ";
                ssql = ssql + "  State, Country, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,   ";
                ssql = ssql + "  MobileNumber4, SpouseMobileNumber1, SpouseMobileNumber2, AreYouBornAgain,  ";
                ssql = ssql + "  AreYouBaptizedByImmersion, AreYouBaptizedByHolySpirit, EmploymentStatus,   ";
                ssql = ssql + "  PlaceOfWork, PlaceOfWorkAddress, PlaceOfWorkPhone, Profession,  ";
                ssql = ssql + "  DateJoined, Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup,   ";
                ssql = ssql + "  Reason, StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,  ";
                ssql = ssql + "  StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,  ";
                ssql = ssql + "  StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,  ";
                ssql = ssql + "  emailaddress1, emailaddress2, emailaddress3   ";

                ssql = ssql + "  FROM ChurchMembers  ";

                ssql = ssql + "  where Gender='" + this.cmbMyGender.Text.Trim() + "'    AND  1=1  ";

                String fieldname = cmbField1.Text.ToString().Trim();
                String assign = this.cmbAssign1.Text.ToString().Trim();
                String myvalue = this.txtQryValue1.Text.ToString().Trim();
                if (fieldname.Length > 0 && assign.Length > 0 && myvalue.Length > 0)
                {
                    if (assign == "LIKE")
                    {
                        ssql = ssql + "  and   " + fieldname + " " + assign + " '" + "%" + myvalue + "%'";

                    }
                    if (assign == "=")
                    {
                        ssql = ssql + "  and   " + fieldname + " " + assign + " " + "'" + myvalue + "'";

                    }
                }

                String fieldname1 = cmbField2.Text.ToString().Trim();
                String assign1 = cmbAssign2.Text.ToString().Trim();
                String myvalue1 = this.txtQryValue2.Text.ToString().Trim();
                String myConjuction = this.cmbConjunction2.Text.ToString().Trim();
                if (fieldname1.Length > 0 && assign1.Length > 0 && myvalue1.Length > 0 && myConjuction.Length > 0)
                {
                    if (assign == "LIKE")
                    {
                        ssql = ssql + "  " + myConjuction + "   " + fieldname1 + " " + assign1 + " '" + "%" + myvalue1 + "%'";

                    }
                    if (assign == "=")
                    {
                        ssql = ssql + "  " + myConjuction + "    " + fieldname1 + " " + assign1 + " " + "'" + myvalue1 + "'";

                    }
                }

                SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                                    "password=;server=localhost;" +
                                                    "Trusted_Connection=yes;" +
                                                    "database=CHurch; " +
                                                    "connection timeout=30");

                myConnection.Open();
                SqlCommand sc = new SqlCommand(ssql, myConnection);
                SqlDataReader reader = sc.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);

                dataGridView1.DataSource = dt;

                reader.Close();
                sc.Dispose();
                myConnection.Close();

            }
            else
            {

                MessageBox.Show(" Please select the Gender before you  click on the search box....");
                this.cmbMyGender.Focus();
            }




        }


        private void btnSave_Click(object sender, EventArgs e)
        {

            String strrELATIONSHIP = this.comboBox3.Text;

            String strFirstname = this.txtFIRSTNAME.Text;
            String strMiddlename = this.txtMIDDLENAME.Text;
            String strLastname = this.txtSURNAME.Text;
            String strGender = this.cmbGENDER.Text;

            String strGenotype = this.cmbGENOTYPE.Text;
            String strDateOfBirth = this.dtpDATEOFBIRTH.Value.ToString();

            
            String strBloodGroup = this.cmbBLOODGROUP.Text;

            String strTiteCardNo = this.txtTITHECARDNUMBER.Text;
            String strMobileNumber1 = this.txtMOBILENUMBER1.Text;
            String strMobileNumber2 = this.txtMOBILENUMBER2.Text;
            String strMobileNumber3 = this.txtMOBILENUMBER3.Text;
            String strMobileNumber4 = this.txtMOBILENUMBER4.Text;

            String strAreYouBornAgain = this.cmbAREYOUBORNAGAIN.Text;
            String strAreYouBaptizedByImmersion = this.cmbAREYOUBAPTIZEDBYIMMERSION.Text;
            String strAreYouBaptizedByHolySpirit = this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Text;
            String strEmploymentStatus = this.cmbEMPLOYEESTATUS.Text;
            String strPlaceOfWork = this.txtPLACEOFWORK.Text;
            String strPlaceOfWorkAddress = this.txtPLACEOFWORKADDRESS.Text;
            String strPlaceOfWorkPhone = this.txtPLACEOFWORKPHONENUMBERS.Text;
            String strProfession = this.txtPLACEOFWORKPROFESSION.Text;
            String strDateJoined = this.dtpDATEJOINED.Value.ToString();
            String strHobbies = this.txtHOBBIESANDINTEREST.Text;
            String strSpecialSkills = this.txtSPECIALSKILLS.Text;
            String strSpiritualGifts = this.txtSPIRITUALGIFTS.Text;
            String strPreferredGroup = this.cmdPREFERREDGROUP.Text;
            String strReason = this.txtREASON.Text;
            String strStudentOrGraduate1 = this.cmdStudentOrGraduate1.Text;
            String strInstitustion1 = this.txtACADEMICINSTITUTION1.Text;
            String strCourseOfStudy1 = this.txtCourseOfStudy0.Text;
            String strDegree1 = this.txtDEGREE0.Text;
            String strLevel1 = this.txtLEVEL100.Text;
            String strStudentOrGraduate2 = this.cmdStudentOrGraduate2.Text;
            String strInstitustion2 = this.txtACADEMICINSTITUTION2.Text;
            String strCourseOfStudy2 = this.txtCourseOfStudy2.Text;
            String strDegree2 = this.txtDEGREE2.Text;
            String strLevel2 = this.txtLEVEL200.Text;
            String strStudentOrGraduate3 = this.cmdStudentOrGraduate3.Text;
            String strInstitustion3 = this.txtACADEMICINSTITUTION3.Text;
            String strCourseOfStudy3 = this.txtCourseOfStudy3.Text;
            String strDegree3 = this.txtDEGREE3.Text;
            String strLevel3 = this.txtLEVEL300.Text;

            if (strFirstname.Trim().Length == 0)
            {
                this.txtFIRSTNAME.ForeColor = Color.Green;
                this.txtFIRSTNAME.BackColor = Color.Ivory;
                MessageBox.Show("FirstName Cant Be Empty");
                this.txtFIRSTNAME.Focus();
                return;
            }
            if (strLastname.Trim().Length == 0)
            {
                this.txtSURNAME.ForeColor = Color.Green;
                this.txtSURNAME.BackColor = Color.Ivory;
                MessageBox.Show("SurnName Cant Be Empty");
                this.txtSURNAME.Focus();
                return;
            }
            if (strMobileNumber1.Trim().Length == 0)
            {
                this.txtMOBILENUMBER1.ForeColor = Color.Green;
                this.txtMOBILENUMBER1.BackColor = Color.Ivory;
                MessageBox.Show("MobileNumber1 Cant Be Empty");
                this.txtMOBILENUMBER1.Focus();
                return;
            }
            if (strGender.Trim().Length == 0)
            {
                this.cmbGENDER.ForeColor = Color.Green;
                this.cmbGENDER.BackColor = Color.Ivory;
                MessageBox.Show("Select The GENDER ");
                this.cmbGENDER.Focus();
                return;
            }




            if (strAreYouBornAgain.Trim().Length == 0)
            {
                this.cmbAREYOUBORNAGAIN.ForeColor = Color.Green;
                this.cmbAREYOUBORNAGAIN.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBORNAGAIN.Focus();
                return;
            }
            if (strAreYouBaptizedByImmersion.Trim().Length == 0)
            {
                this.cmbAREYOUBAPTIZEDBYIMMERSION.ForeColor = Color.Green;
                this.cmbAREYOUBAPTIZEDBYIMMERSION.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBAPTIZEDBYIMMERSION.Focus();
                return;
            }
            if (strAreYouBaptizedByHolySpirit.Trim().Length == 0)
            {
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.ForeColor = Color.Green;
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.BackColor = Color.Ivory;
                MessageBox.Show("SPRITUAL INFROMATION CANT  Empty");
                this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Focus();
                return;
            }





            String ssql = " INSERT INTO Dependant(MEMBER_ID,RELATIONSHIP,Firstname, Middlename, Lastname, Gender,   ";
            ssql = ssql + " Genotype, DateOfBirth, BloodGroup, TiteCardNo, ";
            ssql = ssql + " MobileNumber1, MobileNumber2, MobileNumber3, MobileNumber4, ";
            ssql = ssql + " AreYouBornAgain, AreYouBaptizedByImmersion, AreYouBaptizedByHolySpirit, EmploymentStatus, PlaceOfWork,  ";
            ssql = ssql + " PlaceOfWorkAddress, PlaceOfWorkPhone, Profession, DateJoined, Hobbies, SpecialSkills, SpiritualGifts, ";
            ssql = ssql + " PreferredGroup, Reason, StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,  ";
            ssql = ssql + " StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2, StudentOrGraduate3, Institustion3,  ";
            ssql = ssql + " CourseOfStudy3, Degree3, Level3) ";
            ssql = ssql + " VALUES( ";
            ssql = ssql + " '" + memberid + "'";
            ssql = ssql + " ,'" + strrELATIONSHIP.Replace("'", " ") + "'";
            ssql = ssql + " ,'" + strFirstname.Replace("'", " ") + "'";
            ssql = ssql + ",'" + strMiddlename.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLastname.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strGender.Replace("'", " ").Trim() + "'";
            // ssql = ssql + ",'" + strMaritalStatus.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strGenotype.Replace("'", " ").Trim() + "'";
            ssql = ssql + ", '" + strDateOfBirth + "'";
            ssql = ssql + ",'" + strBloodGroup.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strTiteCardNo.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strMobileNumber4.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strAreYouBornAgain.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strAreYouBaptizedByImmersion.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strAreYouBaptizedByHolySpirit.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strEmploymentStatus.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPlaceOfWork.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPlaceOfWorkAddress.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPlaceOfWorkPhone.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strProfession.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDateJoined + "'";
            ssql = ssql + ",'" + strHobbies.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strSpecialSkills.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strSpiritualGifts.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strPreferredGroup.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strReason.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStudentOrGraduate1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strInstitustion1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCourseOfStudy1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDegree1.Replace("'", " ").Trim() + "'";
          ssql = ssql + ",'" + strLevel1.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStudentOrGraduate2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strInstitustion2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCourseOfStudy2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDegree2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLevel2.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strStudentOrGraduate3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strInstitustion3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strCourseOfStudy3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strDegree3.Replace("'", " ").Trim() + "'";
            ssql = ssql + ",'" + strLevel3.Replace("'", " ").Trim() + "'";
            ssql = ssql + " )  ";




            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                       "password=;server=localhost;" +
                                       "Trusted_Connection=yes;" +
                                       "database=CHurch; " +
                                       "connection timeout=30");

            try
            {
                DialogResult bb = new DialogResult();
                bb = MessageBox.Show("Do You wanT to save this record?", "", MessageBoxButtons.OKCancel);
                if (bb == DialogResult.OK)
                {
                    myConnection.Open();
                    SqlCommand CMD = new SqlCommand();
                    CMD.CommandText = ssql;
                    CMD.Connection = myConnection;
                    int numrowsinserted = CMD.ExecuteNonQuery();
                    MessageBox.Show("Successfully Created");

                    ClearFields();

                    //close connection
                    CMD.Dispose();
                    myConnection.Close();
                }




            }
            catch (Exception e1)
            {
                Console.WriteLine(e1.ToString());
                MessageBox.Show("RECORD NOT CREATED!!!! Reason:" + e1.Message.ToString());
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

           
            int selectrowindex = e.RowIndex;
            int index = dataGridView1.CurrentCell.RowIndex;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            this.listView1.Columns.Clear();
            this.listView1.Columns.Add("Relationship",100);
            this.listView1.Columns.Add("Member_ID", 100);
            this.listView1.Columns.Add("Firstname", 100);
            this.listView1.Columns.Add("Middlename", 100);
            this.listView1.Columns.Add("Surname", 100);
            this.listView1.Columns.Add("Gender", 100);
            this.listView1.Columns.Add("MaritalStatus", 100);
            this.listView1.Columns.Add("MobileNumber1", 100);
            this.listView1.Columns.Add("MobileNumber2", 100);
       
            //Member_id, Firstname, Middlename, Lastname, Gender, MaritalStatus,MobileNumber1, MobileNumber2

///0, 1,2,3,4,5,15,16,


            DataGridViewRow rrow = dataGridView1.Rows[selectrowindex];
            //  this.dataGridView1.Rows(e.RowIndex).selected = true;
             memberid = rrow.Cells[0].Value.ToString();
            
            string[] STR = new string[9];
            STR[0] = this.comboBox3.Text.ToString();
         STR[1] = rrow.Cells[0].Value.ToString().PadLeft(10,'0');
           STR[2]=rrow.Cells[1].Value.ToString();
            STR[3]=rrow.Cells[2].Value.ToString();
           STR[4]=rrow.Cells[3].Value.ToString();
           STR[5]=rrow.Cells[4].Value.ToString();
            STR[6]=rrow.Cells[5].Value.ToString();
            STR[7]=rrow.Cells[15].Value.ToString();
            STR[8] = rrow.Cells[16].Value.ToString();
            ListViewItem ll = new ListViewItem(STR);
            this.listView1.Items.Clear();
            this.listView1.Items.Add(ll);

            this.label9.Visible = true;
            this.textBox3.Visible = true;
            ///this.label6.Visible = true;
            this.comboBox3.Visible = true;
            textBox3.Text = rrow.Cells[0].Value.ToString() + "---";
            textBox3.Text = textBox3.Text + rrow.Cells[3].Value.ToString() + ", ";
            textBox3.Text = textBox3.Text + rrow.Cells[2].Value.ToString() + " ";
            textBox3.Text = textBox3.Text + rrow.Cells[1].Value.ToString() + " ";
            textBox3.Text = textBox3.Text + "[" + rrow.Cells[9].Value.ToString() + " ";
            textBox3.Text = textBox3.Text + rrow.Cells[10].Value.ToString() + ", ";
            textBox3.Text = textBox3.Text + rrow.Cells[11].Value.ToString() + " ";
            textBox3.Text = textBox3.Text + rrow.Cells[12].Value.ToString() + " ";
            textBox3.Text = textBox3.Text + rrow.Cells[13].Value.ToString() + " ]";

           

            //this.comboBox3.Visible = true;


            //this.cmbGENDER.Items.Clear();
            SqlConnection myConnectionR = new SqlConnection("user id=dbo;" +
                                              "password=;server=localhost;" +
                                              "Trusted_Connection=yes;" +
                                              "database=CHurch; " +
                                              "connection timeout=30");

            myConnectionR.Open();
            relatype = comboBox3.Text.ToString().Trim();
            String ssqlR = " SELECT distinct GENDER  FROM [Church].[dbo].[RELATIONSHIP] where RELATIONSHIP_TYPE ='" + relatype + "'   ";

            SqlCommand scR = new SqlCommand(ssqlR, myConnectionR);
            SqlDataReader readerR = scR.ExecuteReader();
            DataTable dtR = new DataTable();

            dtR.Columns.Add("GENDER", typeof(string));
            dtR.Load(readerR);
            cmbGENDER.ValueMember = "GENDER";
            cmbGENDER.DisplayMember = "GENDER";
            cmbGENDER.DataSource = dtR;

            readerR.Close();
            scR.Dispose();
            myConnectionR.Close();

            ////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////
            /////////////////////POPULATE THE DEPENDANT ;LIST///////////////////////////////////////////////
           // int selectrowindex1 = e.RowIndex;
          //  int index1 = dataGridView1.CurrentCell.RowIndex;
          //  this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


          //  DataGridViewRow rrow1 = dataGridView1.Rows[selectrowindex];


            String mEmBERID = rrow.Cells[0].Value.ToString();

            String sqlDependant = "  SELECT Dependant_Member_id, Relationship, Member_id, Firstname,    ";
            sqlDependant = sqlDependant + " Middlename, Lastname, Gender, Genotype, DateOfBirth,     ";
            sqlDependant = sqlDependant + " BloodGroup, TiteCardNo, MobileNumber1, MobileNumber2, MobileNumber3,     ";
            sqlDependant = sqlDependant + " MobileNumber4, AreYouBornAgain, AreYouBaptizedByImmersion,     ";
            sqlDependant = sqlDependant + " AreYouBaptizedByHolySpirit, EmploymentStatus, PlaceOfWork,     ";
            sqlDependant = sqlDependant + " PlaceOfWorkAddress, PlaceOfWorkPhone, Profession, DateJoined,    ";
            sqlDependant = sqlDependant + "  Hobbies, SpecialSkills, SpiritualGifts, PreferredGroup, Reason,    ";
            sqlDependant = sqlDependant + " StudentOrGraduate1, Institustion1, CourseOfStudy1, Degree1, Level1,     ";
            sqlDependant = sqlDependant + " StudentOrGraduate2, Institustion2, CourseOfStudy2, Degree2, Level2,     ";
            sqlDependant = sqlDependant + " StudentOrGraduate3, Institustion3, CourseOfStudy3, Degree3, Level3,     ";
            sqlDependant = sqlDependant + " emailaddress1, emailaddress2, emailaddress3 FROM Dependant    ";
            sqlDependant = sqlDependant + " where  Member_id = " + rrow.Cells[0].Value.ToString();


            SqlConnection myConnection = new SqlConnection("user id=dbo;" +
                                    "password=;server=localhost;" +
                                    "Trusted_Connection=yes;" +
                                    "database=CHurch; " +
                                    "connection timeout=30");

            myConnection.Open();
            SqlCommand sc = new SqlCommand(sqlDependant, myConnection);
            SqlDataReader reader = sc.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(reader);

            this.dataridDependants.DataSource = dt;

            reader.Close();
            sc.Dispose();
            myConnection.Close();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            dataGridView1.Enabled = false;
            if (FLAG == 0)
            { this.tabControl1.SelectedIndex = 0; }
            else
            { this.tabControl1.SelectedIndex = 1; }




          
        }

        private void tabControl1_MouseClick(object sender, MouseEventArgs e)
        {
            dataGridView1.Enabled = true;
        }

        private void tabControl1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            dataGridView1.Enabled = true;
        }


        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            FLAG = 0;

            

  



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           

        }

        private void comboBox3_SelectedIndexChanged_1(object sender, EventArgs e)
        {
             //this.cmbGENDER.Items.Clear();
           

                FLAG = 0;
                SqlConnection myConnectionR = new SqlConnection("user id=dbo;" +
                                                  "password=;server=localhost;" +
                                                  "Trusted_Connection=yes;" +
                                                  "database=CHurch; " +
                                                  "connection timeout=30");

                myConnectionR.Open();
                relatype = comboBox3.Text.ToString().Trim();
                String ssqlR = " SELECT distinct GENDER  FROM [Church].[dbo].[RELATIONSHIP] where RELATIONSHIP_TYPE ='" + relatype + "'   ";

                SqlCommand scR = new SqlCommand(ssqlR, myConnectionR);
                SqlDataReader readerR = scR.ExecuteReader();
                DataTable dtR = new DataTable();

                dtR.Columns.Add("GENDER", typeof(string));
                dtR.Load(readerR);
                cmbGENDER.ValueMember = "GENDER";
                cmbGENDER.DisplayMember = "GENDER";
                cmbGENDER.DataSource = dtR;

                readerR.Close();
                scR.Dispose();
                myConnectionR.Close();

                ////set the flag to 0
                FLAG = 0;

         

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
  
        }

        private void btnRELATIONSIP_Click(object sender, EventArgs e)
        {
            comboBox3.DataSource = null;
            this.comboBox3.Items.Clear();
            String genderforsearch = cmbMyGender.Text;

            if (genderforsearch.Trim().Length > 0)
            {
                String MALESTR = "";
                if (genderforsearch.Trim().Equals("MALE"))
                {
                    MALESTR = "SELECT  DISTINCT [RELATIONSHIP_TYPE] FROM [Church].[dbo].[RELATIONSHIP]";
                    MALESTR = MALESTR + " WHERE RELATIONSHIP_TYPE != 'HUSBAND'";
                    comboBox3.BackColor = Color.Aquamarine;
                }
                if (genderforsearch.Trim().Equals("FEMALE"))
                {
                    MALESTR = "SELECT  DISTINCT [RELATIONSHIP_TYPE] FROM [Church].[dbo].[RELATIONSHIP]";
                    MALESTR = MALESTR + " WHERE RELATIONSHIP_TYPE != 'WIFE'";
                    comboBox3.BackColor = Color.Pink;
                }

                FLAG = 0;
                SqlConnection myConnectionR = new SqlConnection("user id=dbo;" +
                                                  "password=;server=localhost;" +
                                                  "Trusted_Connection=yes;" +
                                                  "database=CHurch; " +
                                                  "connection timeout=30");

                myConnectionR.Open();
              

                SqlCommand scR = new SqlCommand(MALESTR, myConnectionR);
                SqlDataReader readerR = scR.ExecuteReader();
                DataTable dtR = new DataTable();

                dtR.Columns.Add("RELATIONSHIP_TYPE", typeof(string));
                dtR.Load(readerR);
                comboBox3.ValueMember = "RELATIONSHIP_TYPE";
                comboBox3.DisplayMember = "RELATIONSHIP_TYPE";
                comboBox3.DataSource = dtR;

                readerR.Close();
                scR.Dispose();
                myConnectionR.Close();

                ////set the flag to 0
                FLAG = 0;

            }
            else
            {
         
                MessageBox.Show("Select The enter to populate the RELATIONSHIP .........");
                this.cmbMyGender.Focus();
            }


        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       
       
        
       

      

    }
}

       
     
      




    
