namespace DCM
{
    partial class Depandent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label33 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label39 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtInstitution = new System.Windows.Forms.TextBox();
            this.txtLEVEL = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.cmbStudGrad = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.cmdBaptizedImmersion = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cmbBornAgain = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.listView1 = new System.Windows.Forms.ListView();
            this.Firstname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Surname = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Gender = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MaritalStatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MobileNumber1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MobileNumber2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtREASON = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.cmdPREFERREDGROUP = new System.Windows.Forms.ComboBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtSPIRITUALGIFTS = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtSPECIALSKILLS = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.txtHOBBIESANDINTEREST = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.dtpDATEJOINED = new System.Windows.Forms.DateTimePicker();
            this.label50 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtPLACEOFWORKPROFESSION = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtPLACEOFWORKPHONENUMBERS = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtPLACEOFWORKADDRESS = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.txtPLACEOFWORK = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.cmbEMPLOYEESTATUS = new System.Windows.Forms.ComboBox();
            this.label55 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtDEGREE3 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.txtLEVEL300 = new System.Windows.Forms.TextBox();
            this.txtCourseOfStudy3 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.txtACADEMICINSTITUTION3 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.cmdStudentOrGraduate3 = new System.Windows.Forms.ComboBox();
            this.label59 = new System.Windows.Forms.Label();
            this.txtDEGREE2 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtLEVEL200 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.txtLEVEL100 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txtDEGREE0 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.txtCourseOfStudy2 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.txtACADEMICINSTITUTION2 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.cmdStudentOrGraduate2 = new System.Windows.Forms.ComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.txtCourseOfStudy0 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.txtACADEMICINSTITUTION1 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.cmdStudentOrGraduate1 = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.cmbAREYOUBAPTIZEDBYIMMERSION = new System.Windows.Forms.ComboBox();
            this.label71 = new System.Windows.Forms.Label();
            this.cmbAREYOUBORNAGAIN = new System.Windows.Forms.ComboBox();
            this.label72 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtEmailAddress3 = new System.Windows.Forms.TextBox();
            this.txtEmailAddress2 = new System.Windows.Forms.TextBox();
            this.txtEmailAddress1 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtTITHECARDNUMBER = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtMOBILENUMBER4 = new System.Windows.Forms.TextBox();
            this.txtMOBILENUMBER2 = new System.Windows.Forms.TextBox();
            this.txtMOBILENUMBER3 = new System.Windows.Forms.TextBox();
            this.txtMOBILENUMBER1 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.dtpDATEOFBIRTH = new System.Windows.Forms.DateTimePicker();
            this.label81 = new System.Windows.Forms.Label();
            this.cmbBLOODGROUP = new System.Windows.Forms.ComboBox();
            this.label83 = new System.Windows.Forms.Label();
            this.cmbGENOTYPE = new System.Windows.Forms.ComboBox();
            this.label84 = new System.Windows.Forms.Label();
            this.cmbGENDER = new System.Windows.Forms.ComboBox();
            this.label85 = new System.Windows.Forms.Label();
            this.txtSURNAME = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.txtMIDDLENAME = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.txtFIRSTNAME = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnRELATIONSIP = new System.Windows.Forms.Button();
            this.cmbMyGender = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.cmbAssign2 = new System.Windows.Forms.ComboBox();
            this.txtQryValue2 = new System.Windows.Forms.TextBox();
            this.cmbField2 = new System.Windows.Forms.ComboBox();
            this.cmbConjunction2 = new System.Windows.Forms.ComboBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtQryValue1 = new System.Windows.Forms.TextBox();
            this.cmbAssign1 = new System.Windows.Forms.ComboBox();
            this.cmbField1 = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataridDependants = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataridDependants)).BeginInit();
            this.SuspendLayout();
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(27, -64);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(135, 13);
            this.label33.TabIndex = 78;
            this.label33.Text = "EMPLOYEMENT STATUS";
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "SELF EMPLOYED",
            "BUSINSESS OWNER",
            "EMPLOYEE",
            "ARTISAN"});
            this.comboBox7.Location = new System.Drawing.Point(168, -67);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(215, 21);
            this.comboBox7.TabIndex = 83;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(27, -52);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(95, 13);
            this.label38.TabIndex = 124;
            this.label38.Text = "DATE OF JOINED";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(130, -55);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(159, 20);
            this.dateTimePicker2.TabIndex = 126;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(27, -23);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(113, 13);
            this.label39.TabIndex = 129;
            this.label39.Text = "HOBBIES/INTEREST";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(27, -19);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(59, 13);
            this.label34.TabIndex = 104;
            this.label34.Text = "ADDRESS";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(168, -41);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(309, 20);
            this.textBox17.TabIndex = 103;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(27, -40);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(95, 13);
            this.label35.TabIndex = 100;
            this.label35.Text = "PLACE OF WORK";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(599, -31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 13);
            this.label8.TabIndex = 73;
            this.label8.Text = "DATE OF BIRTH";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(702, -68);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(159, 21);
            this.comboBox4.TabIndex = 72;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, -12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 63;
            this.label3.Text = "SURNAME";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(126, -41);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(238, 20);
            this.textBox2.TabIndex = 62;
            this.textBox2.Text = " ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, -38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 61;
            this.label2.Text = "MIDDLE NAME";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(126, -67);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(238, 20);
            this.textBox1.TabIndex = 60;
            this.textBox1.Text = "  ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, -64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 59;
            this.label1.Text = "FIRSTNAME";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(373, -62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 65;
            this.label4.Text = "GENDER";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(469, -68);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 66;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(596, -64);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 13);
            this.label7.TabIndex = 71;
            this.label7.Text = "MARITAL STATUS";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(469, -38);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(373, -34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 67;
            this.label5.Text = "GENOTYPE";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(28, -16);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(109, 13);
            this.label21.TabIndex = 90;
            this.label21.Text = "COURSE OF STUDY";
            // 
            // txtInstitution
            // 
            this.txtInstitution.Location = new System.Drawing.Point(160, -45);
            this.txtInstitution.Name = "txtInstitution";
            this.txtInstitution.Size = new System.Drawing.Size(343, 20);
            this.txtInstitution.TabIndex = 88;
            this.txtInstitution.Text = "  ";
            // 
            // txtLEVEL
            // 
            this.txtLEVEL.Location = new System.Drawing.Point(372, -70);
            this.txtLEVEL.Name = "txtLEVEL";
            this.txtLEVEL.Size = new System.Drawing.Size(87, 20);
            this.txtLEVEL.TabIndex = 119;
            this.txtLEVEL.Text = "       ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(326, -67);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 13);
            this.label26.TabIndex = 117;
            this.label26.Text = "LEVEL";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(28, -39);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(76, 13);
            this.label20.TabIndex = 86;
            this.label20.Text = "INSTITUTION";
            // 
            // cmbStudGrad
            // 
            this.cmbStudGrad.FormattingEnabled = true;
            this.cmbStudGrad.Items.AddRange(new object[] {
            "STUDENT",
            "GRADUATE"});
            this.cmbStudGrad.Location = new System.Drawing.Point(160, -67);
            this.cmbStudGrad.Name = "cmbStudGrad";
            this.cmbStudGrad.Size = new System.Drawing.Size(113, 21);
            this.cmbStudGrad.TabIndex = 82;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(27, -63);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(127, 13);
            this.label19.TabIndex = 79;
            this.label19.Text = "STUDENT/ GRADUATE";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(27, -57);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(125, 13);
            this.label16.TabIndex = 75;
            this.label16.Text = "ARE YOU BORN AGAIN";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.comboBox5.Location = new System.Drawing.Point(229, -37);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(51, 21);
            this.comboBox5.TabIndex = 89;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(27, -37);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(201, 13);
            this.label18.TabIndex = 87;
            this.label18.Text = "ARE YOU BAPTIZED(BY HOLY SPIRIT)";
            // 
            // cmdBaptizedImmersion
            // 
            this.cmdBaptizedImmersion.FormattingEnabled = true;
            this.cmdBaptizedImmersion.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.cmdBaptizedImmersion.Location = new System.Drawing.Point(417, -63);
            this.cmdBaptizedImmersion.Name = "cmdBaptizedImmersion";
            this.cmdBaptizedImmersion.Size = new System.Drawing.Size(51, 21);
            this.cmdBaptizedImmersion.TabIndex = 84;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(215, -58);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(196, 13);
            this.label17.TabIndex = 81;
            this.label17.Text = "ARE YOU BAPTIZED(BY IMMERSION)";
            // 
            // cmbBornAgain
            // 
            this.cmbBornAgain.FormattingEnabled = true;
            this.cmbBornAgain.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.cmbBornAgain.Location = new System.Drawing.Point(158, -61);
            this.cmbBornAgain.Name = "cmbBornAgain";
            this.cmbBornAgain.Size = new System.Drawing.Size(51, 21);
            this.cmbBornAgain.TabIndex = 77;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(2, -1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(995, 680);
            this.tabControl1.TabIndex = 130;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseClick);
            this.tabControl1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tabControl1_MouseDoubleClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.listView1);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.btnSave);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(987, 654);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Dependant Form";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Firstname,
            this.Surname,
            this.Gender,
            this.MaritalStatus,
            this.MobileNumber1,
            this.MobileNumber2});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.listView1.Location = new System.Drawing.Point(-4, 3);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(988, 52);
            this.listView1.TabIndex = 53;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // Surname
            // 
            this.Surname.Width = 0;
            // 
            // MobileNumber2
            // 
            this.MobileNumber2.Width = 3;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gray;
            this.button3.Location = new System.Drawing.Point(330, 622);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(153, 23);
            this.button3.TabIndex = 52;
            this.button3.Text = "ClearFields";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gray;
            this.button2.Location = new System.Drawing.Point(171, 622);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(153, 23);
            this.button2.TabIndex = 51;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Gray;
            this.btnSave.Location = new System.Drawing.Point(12, 622);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(153, 23);
            this.btnSave.TabIndex = 50;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(218, -28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtREASON);
            this.groupBox7.Controls.Add(this.label45);
            this.groupBox7.Controls.Add(this.cmdPREFERREDGROUP);
            this.groupBox7.Controls.Add(this.label46);
            this.groupBox7.Controls.Add(this.txtSPIRITUALGIFTS);
            this.groupBox7.Controls.Add(this.label47);
            this.groupBox7.Controls.Add(this.txtSPECIALSKILLS);
            this.groupBox7.Controls.Add(this.label48);
            this.groupBox7.Controls.Add(this.txtHOBBIESANDINTEREST);
            this.groupBox7.Controls.Add(this.label49);
            this.groupBox7.Controls.Add(this.dtpDATEJOINED);
            this.groupBox7.Controls.Add(this.label50);
            this.groupBox7.Location = new System.Drawing.Point(500, 445);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(480, 177);
            this.groupBox7.TabIndex = 8;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "GENERAL INFORMATION";
            // 
            // txtREASON
            // 
            this.txtREASON.Location = new System.Drawing.Point(110, 154);
            this.txtREASON.MaxLength = 100;
            this.txtREASON.Name = "txtREASON";
            this.txtREASON.Size = new System.Drawing.Size(364, 20);
            this.txtREASON.TabIndex = 44;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(6, 161);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(52, 13);
            this.label45.TabIndex = 56;
            this.label45.Text = "REASON";
            // 
            // cmdPREFERREDGROUP
            // 
            this.cmdPREFERREDGROUP.BackColor = System.Drawing.Color.Yellow;
            this.cmdPREFERREDGROUP.FormattingEnabled = true;
            this.cmdPREFERREDGROUP.Location = new System.Drawing.Point(112, 127);
            this.cmdPREFERREDGROUP.Name = "cmdPREFERREDGROUP";
            this.cmdPREFERREDGROUP.Size = new System.Drawing.Size(361, 21);
            this.cmdPREFERREDGROUP.TabIndex = 43;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(6, 130);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(107, 13);
            this.label46.TabIndex = 54;
            this.label46.Text = "PREFERED GROUP";
            // 
            // txtSPIRITUALGIFTS
            // 
            this.txtSPIRITUALGIFTS.Location = new System.Drawing.Point(110, 97);
            this.txtSPIRITUALGIFTS.MaxLength = 100;
            this.txtSPIRITUALGIFTS.Name = "txtSPIRITUALGIFTS";
            this.txtSPIRITUALGIFTS.Size = new System.Drawing.Size(364, 20);
            this.txtSPIRITUALGIFTS.TabIndex = 42;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 104);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(97, 13);
            this.label47.TabIndex = 52;
            this.label47.Text = "SPIRITUAL GIFTS";
            // 
            // txtSPECIALSKILLS
            // 
            this.txtSPECIALSKILLS.Location = new System.Drawing.Point(109, 74);
            this.txtSPECIALSKILLS.MaxLength = 100;
            this.txtSPECIALSKILLS.Name = "txtSPECIALSKILLS";
            this.txtSPECIALSKILLS.Size = new System.Drawing.Size(364, 20);
            this.txtSPECIALSKILLS.TabIndex = 41;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(5, 81);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(90, 13);
            this.label48.TabIndex = 50;
            this.label48.Text = "SPECIAL SKILLS";
            // 
            // txtHOBBIESANDINTEREST
            // 
            this.txtHOBBIESANDINTEREST.Location = new System.Drawing.Point(110, 50);
            this.txtHOBBIESANDINTEREST.MaxLength = 100;
            this.txtHOBBIESANDINTEREST.Name = "txtHOBBIESANDINTEREST";
            this.txtHOBBIESANDINTEREST.Size = new System.Drawing.Size(364, 20);
            this.txtHOBBIESANDINTEREST.TabIndex = 40;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(6, 57);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(113, 13);
            this.label49.TabIndex = 48;
            this.label49.Text = "HOBBIES/INTEREST";
            // 
            // dtpDATEJOINED
            // 
            this.dtpDATEJOINED.CustomFormat = "DD-MON-YYYY";
            this.dtpDATEJOINED.Location = new System.Drawing.Point(109, 25);
            this.dtpDATEJOINED.Name = "dtpDATEJOINED";
            this.dtpDATEJOINED.Size = new System.Drawing.Size(159, 20);
            this.dtpDATEJOINED.TabIndex = 39;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(6, 28);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(95, 13);
            this.label50.TabIndex = 46;
            this.label50.Text = "DATE OF JOINED";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.txtPLACEOFWORKPROFESSION);
            this.groupBox6.Controls.Add(this.label51);
            this.groupBox6.Controls.Add(this.txtPLACEOFWORKPHONENUMBERS);
            this.groupBox6.Controls.Add(this.label52);
            this.groupBox6.Controls.Add(this.txtPLACEOFWORKADDRESS);
            this.groupBox6.Controls.Add(this.label53);
            this.groupBox6.Controls.Add(this.txtPLACEOFWORK);
            this.groupBox6.Controls.Add(this.label54);
            this.groupBox6.Controls.Add(this.cmbEMPLOYEESTATUS);
            this.groupBox6.Controls.Add(this.label55);
            this.groupBox6.Location = new System.Drawing.Point(501, 296);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(480, 143);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "WORK/PROFESSIONAL INFORMATION";
            // 
            // txtPLACEOFWORKPROFESSION
            // 
            this.txtPLACEOFWORKPROFESSION.Location = new System.Drawing.Point(147, 116);
            this.txtPLACEOFWORKPROFESSION.Name = "txtPLACEOFWORKPROFESSION";
            this.txtPLACEOFWORKPROFESSION.Size = new System.Drawing.Size(309, 20);
            this.txtPLACEOFWORKPROFESSION.TabIndex = 38;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(6, 119);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(76, 13);
            this.label51.TabIndex = 44;
            this.label51.Text = "PROFESSION";
            // 
            // txtPLACEOFWORKPHONENUMBERS
            // 
            this.txtPLACEOFWORKPHONENUMBERS.Location = new System.Drawing.Point(147, 90);
            this.txtPLACEOFWORKPHONENUMBERS.MaxLength = 100;
            this.txtPLACEOFWORKPHONENUMBERS.Name = "txtPLACEOFWORKPHONENUMBERS";
            this.txtPLACEOFWORKPHONENUMBERS.Size = new System.Drawing.Size(309, 20);
            this.txtPLACEOFWORKPHONENUMBERS.TabIndex = 37;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 87);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(102, 13);
            this.label52.TabIndex = 42;
            this.label52.Text = "PHONE NUMBERS";
            // 
            // txtPLACEOFWORKADDRESS
            // 
            this.txtPLACEOFWORKADDRESS.Location = new System.Drawing.Point(148, 64);
            this.txtPLACEOFWORKADDRESS.MaxLength = 100;
            this.txtPLACEOFWORKADDRESS.Name = "txtPLACEOFWORKADDRESS";
            this.txtPLACEOFWORKADDRESS.Size = new System.Drawing.Size(309, 20);
            this.txtPLACEOFWORKADDRESS.TabIndex = 36;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(6, 61);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(59, 13);
            this.label53.TabIndex = 40;
            this.label53.Text = "ADDRESS";
            // 
            // txtPLACEOFWORK
            // 
            this.txtPLACEOFWORK.Location = new System.Drawing.Point(147, 39);
            this.txtPLACEOFWORK.MaxLength = 100;
            this.txtPLACEOFWORK.Name = "txtPLACEOFWORK";
            this.txtPLACEOFWORK.Size = new System.Drawing.Size(309, 20);
            this.txtPLACEOFWORK.TabIndex = 35;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(6, 40);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(95, 13);
            this.label54.TabIndex = 38;
            this.label54.Text = "PLACE OF WORK";
            // 
            // cmbEMPLOYEESTATUS
            // 
            this.cmbEMPLOYEESTATUS.FormattingEnabled = true;
            this.cmbEMPLOYEESTATUS.Items.AddRange(new object[] {
            "SELF EMPLOYED",
            "BUSINSESS OWNER",
            "EMPLOYEE (GOVERNMENT)",
            "EMPLOYEE (PRIVATE)",
            "MILITARY",
            "PARA-MILITARY",
            ""});
            this.cmbEMPLOYEESTATUS.Location = new System.Drawing.Point(147, 13);
            this.cmbEMPLOYEESTATUS.Name = "cmbEMPLOYEESTATUS";
            this.cmbEMPLOYEESTATUS.Size = new System.Drawing.Size(215, 21);
            this.cmbEMPLOYEESTATUS.TabIndex = 34;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(6, 16);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(135, 13);
            this.label55.TabIndex = 30;
            this.label55.Text = "EMPLOYEMENT STATUS";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtDEGREE3);
            this.groupBox5.Controls.Add(this.label56);
            this.groupBox5.Controls.Add(this.txtLEVEL300);
            this.groupBox5.Controls.Add(this.txtCourseOfStudy3);
            this.groupBox5.Controls.Add(this.label57);
            this.groupBox5.Controls.Add(this.txtACADEMICINSTITUTION3);
            this.groupBox5.Controls.Add(this.label58);
            this.groupBox5.Controls.Add(this.cmdStudentOrGraduate3);
            this.groupBox5.Controls.Add(this.label59);
            this.groupBox5.Controls.Add(this.txtDEGREE2);
            this.groupBox5.Controls.Add(this.label60);
            this.groupBox5.Controls.Add(this.txtLEVEL200);
            this.groupBox5.Controls.Add(this.label61);
            this.groupBox5.Controls.Add(this.txtLEVEL100);
            this.groupBox5.Controls.Add(this.label62);
            this.groupBox5.Controls.Add(this.txtDEGREE0);
            this.groupBox5.Controls.Add(this.label63);
            this.groupBox5.Controls.Add(this.txtCourseOfStudy2);
            this.groupBox5.Controls.Add(this.label64);
            this.groupBox5.Controls.Add(this.txtACADEMICINSTITUTION2);
            this.groupBox5.Controls.Add(this.label65);
            this.groupBox5.Controls.Add(this.cmdStudentOrGraduate2);
            this.groupBox5.Controls.Add(this.label66);
            this.groupBox5.Controls.Add(this.txtCourseOfStudy0);
            this.groupBox5.Controls.Add(this.label67);
            this.groupBox5.Controls.Add(this.txtACADEMICINSTITUTION1);
            this.groupBox5.Controls.Add(this.label68);
            this.groupBox5.Controls.Add(this.cmdStudentOrGraduate1);
            this.groupBox5.Controls.Add(this.label69);
            this.groupBox5.Location = new System.Drawing.Point(2, 203);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(494, 333);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "ACADEMIC INFORMATION";
            // 
            // txtDEGREE3
            // 
            this.txtDEGREE3.Location = new System.Drawing.Point(143, 297);
            this.txtDEGREE3.MaxLength = 50;
            this.txtDEGREE3.Name = "txtDEGREE3";
            this.txtDEGREE3.Size = new System.Drawing.Size(234, 20);
            this.txtDEGREE3.TabIndex = 30;
            this.txtDEGREE3.Text = "       ";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(11, 300);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(52, 13);
            this.label56.TabIndex = 57;
            this.label56.Text = "DEGREE";
            // 
            // txtLEVEL300
            // 
            this.txtLEVEL300.Location = new System.Drawing.Point(354, 223);
            this.txtLEVEL300.Name = "txtLEVEL300";
            this.txtLEVEL300.Size = new System.Drawing.Size(87, 20);
            this.txtLEVEL300.TabIndex = 28;
            this.txtLEVEL300.Text = "       ";
            // 
            // txtCourseOfStudy3
            // 
            this.txtCourseOfStudy3.Location = new System.Drawing.Point(142, 272);
            this.txtCourseOfStudy3.MaxLength = 50;
            this.txtCourseOfStudy3.Name = "txtCourseOfStudy3";
            this.txtCourseOfStudy3.Size = new System.Drawing.Size(343, 20);
            this.txtCourseOfStudy3.TabIndex = 29;
            this.txtCourseOfStudy3.Text = "  ";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(10, 278);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(109, 13);
            this.label57.TabIndex = 54;
            this.label57.Text = "COURSE OF STUDY";
            // 
            // txtACADEMICINSTITUTION3
            // 
            this.txtACADEMICINSTITUTION3.Location = new System.Drawing.Point(142, 249);
            this.txtACADEMICINSTITUTION3.MaxLength = 50;
            this.txtACADEMICINSTITUTION3.Name = "txtACADEMICINSTITUTION3";
            this.txtACADEMICINSTITUTION3.Size = new System.Drawing.Size(343, 20);
            this.txtACADEMICINSTITUTION3.TabIndex = 28;
            this.txtACADEMICINSTITUTION3.Text = "  ";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(10, 255);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(76, 13);
            this.label58.TabIndex = 52;
            this.label58.Text = "INSTITUTION";
            // 
            // cmdStudentOrGraduate3
            // 
            this.cmdStudentOrGraduate3.FormattingEnabled = true;
            this.cmdStudentOrGraduate3.Items.AddRange(new object[] {
            "STUDENT",
            "GRADUATE"});
            this.cmdStudentOrGraduate3.Location = new System.Drawing.Point(142, 227);
            this.cmdStudentOrGraduate3.Name = "cmdStudentOrGraduate3";
            this.cmdStudentOrGraduate3.Size = new System.Drawing.Size(113, 21);
            this.cmdStudentOrGraduate3.TabIndex = 27;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(9, 231);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(127, 13);
            this.label59.TabIndex = 50;
            this.label59.Text = "STUDENT/ GRADUATE";
            // 
            // txtDEGREE2
            // 
            this.txtDEGREE2.Location = new System.Drawing.Point(140, 193);
            this.txtDEGREE2.MaxLength = 50;
            this.txtDEGREE2.Name = "txtDEGREE2";
            this.txtDEGREE2.Size = new System.Drawing.Size(234, 20);
            this.txtDEGREE2.TabIndex = 26;
            this.txtDEGREE2.Text = "       ";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(8, 196);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(52, 13);
            this.label60.TabIndex = 48;
            this.label60.Text = "DEGREE";
            // 
            // txtLEVEL200
            // 
            this.txtLEVEL200.Location = new System.Drawing.Point(351, 119);
            this.txtLEVEL200.Name = "txtLEVEL200";
            this.txtLEVEL200.Size = new System.Drawing.Size(87, 20);
            this.txtLEVEL200.TabIndex = 23;
            this.txtLEVEL200.Text = "       ";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(305, 122);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(40, 13);
            this.label61.TabIndex = 46;
            this.label61.Text = "LEVEL";
            // 
            // txtLEVEL100
            // 
            this.txtLEVEL100.Location = new System.Drawing.Point(351, 10);
            this.txtLEVEL100.Name = "txtLEVEL100";
            this.txtLEVEL100.Size = new System.Drawing.Size(87, 20);
            this.txtLEVEL100.TabIndex = 17;
            this.txtLEVEL100.Text = "       ";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(305, 13);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(40, 13);
            this.label62.TabIndex = 44;
            this.label62.Text = "LEVEL";
            // 
            // txtDEGREE0
            // 
            this.txtDEGREE0.Location = new System.Drawing.Point(139, 83);
            this.txtDEGREE0.MaxLength = 50;
            this.txtDEGREE0.Name = "txtDEGREE0";
            this.txtDEGREE0.Size = new System.Drawing.Size(234, 20);
            this.txtDEGREE0.TabIndex = 20;
            this.txtDEGREE0.Text = "       ";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(7, 86);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(52, 13);
            this.label63.TabIndex = 42;
            this.label63.Text = "DEGREE";
            // 
            // txtCourseOfStudy2
            // 
            this.txtCourseOfStudy2.Location = new System.Drawing.Point(140, 167);
            this.txtCourseOfStudy2.MaxLength = 50;
            this.txtCourseOfStudy2.Name = "txtCourseOfStudy2";
            this.txtCourseOfStudy2.Size = new System.Drawing.Size(343, 20);
            this.txtCourseOfStudy2.TabIndex = 25;
            this.txtCourseOfStudy2.Text = "  ";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(7, 174);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(109, 13);
            this.label64.TabIndex = 40;
            this.label64.Text = "COURSE OF STUDY";
            // 
            // txtACADEMICINSTITUTION2
            // 
            this.txtACADEMICINSTITUTION2.Location = new System.Drawing.Point(139, 148);
            this.txtACADEMICINSTITUTION2.MaxLength = 50;
            this.txtACADEMICINSTITUTION2.Name = "txtACADEMICINSTITUTION2";
            this.txtACADEMICINSTITUTION2.Size = new System.Drawing.Size(343, 20);
            this.txtACADEMICINSTITUTION2.TabIndex = 24;
            this.txtACADEMICINSTITUTION2.Text = "  ";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(7, 151);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(76, 13);
            this.label65.TabIndex = 38;
            this.label65.Text = "INSTITUTION";
            // 
            // cmdStudentOrGraduate2
            // 
            this.cmdStudentOrGraduate2.FormattingEnabled = true;
            this.cmdStudentOrGraduate2.Items.AddRange(new object[] {
            "STUDENT",
            "GRADUATE"});
            this.cmdStudentOrGraduate2.Location = new System.Drawing.Point(139, 123);
            this.cmdStudentOrGraduate2.Name = "cmdStudentOrGraduate2";
            this.cmdStudentOrGraduate2.Size = new System.Drawing.Size(113, 21);
            this.cmdStudentOrGraduate2.TabIndex = 22;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(6, 127);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(127, 13);
            this.label66.TabIndex = 36;
            this.label66.Text = "STUDENT/ GRADUATE";
            // 
            // txtCourseOfStudy0
            // 
            this.txtCourseOfStudy0.Location = new System.Drawing.Point(139, 58);
            this.txtCourseOfStudy0.MaxLength = 50;
            this.txtCourseOfStudy0.Name = "txtCourseOfStudy0";
            this.txtCourseOfStudy0.Size = new System.Drawing.Size(343, 20);
            this.txtCourseOfStudy0.TabIndex = 19;
            this.txtCourseOfStudy0.Text = "  ";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(7, 64);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(109, 13);
            this.label67.TabIndex = 34;
            this.label67.Text = "COURSE OF STUDY";
            // 
            // txtACADEMICINSTITUTION1
            // 
            this.txtACADEMICINSTITUTION1.Location = new System.Drawing.Point(139, 35);
            this.txtACADEMICINSTITUTION1.MaxLength = 50;
            this.txtACADEMICINSTITUTION1.Name = "txtACADEMICINSTITUTION1";
            this.txtACADEMICINSTITUTION1.Size = new System.Drawing.Size(343, 20);
            this.txtACADEMICINSTITUTION1.TabIndex = 18;
            this.txtACADEMICINSTITUTION1.Text = "  ";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(7, 41);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(76, 13);
            this.label68.TabIndex = 32;
            this.label68.Text = "INSTITUTION";
            // 
            // cmdStudentOrGraduate1
            // 
            this.cmdStudentOrGraduate1.FormattingEnabled = true;
            this.cmdStudentOrGraduate1.Items.AddRange(new object[] {
            "STUDENT",
            "GRADUATE"});
            this.cmdStudentOrGraduate1.Location = new System.Drawing.Point(139, 13);
            this.cmdStudentOrGraduate1.Name = "cmdStudentOrGraduate1";
            this.cmdStudentOrGraduate1.Size = new System.Drawing.Size(113, 21);
            this.cmdStudentOrGraduate1.TabIndex = 16;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(6, 17);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(127, 13);
            this.label69.TabIndex = 30;
            this.label69.Text = "STUDENT/ GRADUATE";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT);
            this.groupBox4.Controls.Add(this.label70);
            this.groupBox4.Controls.Add(this.cmbAREYOUBAPTIZEDBYIMMERSION);
            this.groupBox4.Controls.Add(this.label71);
            this.groupBox4.Controls.Add(this.cmbAREYOUBORNAGAIN);
            this.groupBox4.Controls.Add(this.label72);
            this.groupBox4.Location = new System.Drawing.Point(501, 213);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(481, 77);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "SPIRITUAL INFORMATION";
            // 
            // cmbAREYOUBAPTIZEDBYHOLYSPIRIT
            // 
            this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.BackColor = System.Drawing.Color.Yellow;
            this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.FormattingEnabled = true;
            this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Location = new System.Drawing.Point(208, 43);
            this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Name = "cmbAREYOUBAPTIZEDBYHOLYSPIRIT";
            this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.Size = new System.Drawing.Size(51, 21);
            this.cmbAREYOUBAPTIZEDBYHOLYSPIRIT.TabIndex = 33;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(6, 43);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(201, 13);
            this.label70.TabIndex = 32;
            this.label70.Text = "ARE YOU BAPTIZED(BY HOLY SPIRIT)";
            // 
            // cmbAREYOUBAPTIZEDBYIMMERSION
            // 
            this.cmbAREYOUBAPTIZEDBYIMMERSION.BackColor = System.Drawing.Color.Yellow;
            this.cmbAREYOUBAPTIZEDBYIMMERSION.FormattingEnabled = true;
            this.cmbAREYOUBAPTIZEDBYIMMERSION.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.cmbAREYOUBAPTIZEDBYIMMERSION.Location = new System.Drawing.Point(396, 17);
            this.cmbAREYOUBAPTIZEDBYIMMERSION.Name = "cmbAREYOUBAPTIZEDBYIMMERSION";
            this.cmbAREYOUBAPTIZEDBYIMMERSION.Size = new System.Drawing.Size(51, 21);
            this.cmbAREYOUBAPTIZEDBYIMMERSION.TabIndex = 32;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(194, 22);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(196, 13);
            this.label71.TabIndex = 30;
            this.label71.Text = "ARE YOU BAPTIZED(BY IMMERSION)";
            // 
            // cmbAREYOUBORNAGAIN
            // 
            this.cmbAREYOUBORNAGAIN.BackColor = System.Drawing.Color.Yellow;
            this.cmbAREYOUBORNAGAIN.FormattingEnabled = true;
            this.cmbAREYOUBORNAGAIN.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.cmbAREYOUBORNAGAIN.Location = new System.Drawing.Point(137, 19);
            this.cmbAREYOUBORNAGAIN.Name = "cmbAREYOUBORNAGAIN";
            this.cmbAREYOUBORNAGAIN.Size = new System.Drawing.Size(51, 21);
            this.cmbAREYOUBORNAGAIN.TabIndex = 31;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(6, 23);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(125, 13);
            this.label72.TabIndex = 28;
            this.label72.Text = "ARE YOU BORN AGAIN";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox10);
            this.groupBox1.Controls.Add(this.label89);
            this.groupBox1.Controls.Add(this.txtTITHECARDNUMBER);
            this.groupBox1.Controls.Add(this.label73);
            this.groupBox1.Controls.Add(this.groupBox9);
            this.groupBox1.Controls.Add(this.label80);
            this.groupBox1.Controls.Add(this.dtpDATEOFBIRTH);
            this.groupBox1.Controls.Add(this.label81);
            this.groupBox1.Controls.Add(this.cmbBLOODGROUP);
            this.groupBox1.Controls.Add(this.label83);
            this.groupBox1.Controls.Add(this.cmbGENOTYPE);
            this.groupBox1.Controls.Add(this.label84);
            this.groupBox1.Controls.Add(this.cmbGENDER);
            this.groupBox1.Controls.Add(this.label85);
            this.groupBox1.Controls.Add(this.txtSURNAME);
            this.groupBox1.Controls.Add(this.label86);
            this.groupBox1.Controls.Add(this.txtMIDDLENAME);
            this.groupBox1.Controls.Add(this.label87);
            this.groupBox1.Controls.Add(this.txtFIRSTNAME);
            this.groupBox1.Controls.Add(this.label88);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(2, 56);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(980, 159);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PERSONAL DATA";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.txtEmailAddress3);
            this.groupBox10.Controls.Add(this.txtEmailAddress2);
            this.groupBox10.Controls.Add(this.txtEmailAddress1);
            this.groupBox10.Location = new System.Drawing.Point(591, 68);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(249, 91);
            this.groupBox10.TabIndex = 51;
            this.groupBox10.TabStop = false;
            // 
            // txtEmailAddress3
            // 
            this.txtEmailAddress3.Location = new System.Drawing.Point(5, 63);
            this.txtEmailAddress3.MaxLength = 50;
            this.txtEmailAddress3.Name = "txtEmailAddress3";
            this.txtEmailAddress3.Size = new System.Drawing.Size(238, 20);
            this.txtEmailAddress3.TabIndex = 56;
            this.txtEmailAddress3.Text = " ";
            // 
            // txtEmailAddress2
            // 
            this.txtEmailAddress2.Location = new System.Drawing.Point(5, 39);
            this.txtEmailAddress2.MaxLength = 50;
            this.txtEmailAddress2.Name = "txtEmailAddress2";
            this.txtEmailAddress2.Size = new System.Drawing.Size(238, 20);
            this.txtEmailAddress2.TabIndex = 55;
            this.txtEmailAddress2.Text = " ";
            // 
            // txtEmailAddress1
            // 
            this.txtEmailAddress1.Location = new System.Drawing.Point(5, 13);
            this.txtEmailAddress1.MaxLength = 50;
            this.txtEmailAddress1.Name = "txtEmailAddress1";
            this.txtEmailAddress1.Size = new System.Drawing.Size(238, 20);
            this.txtEmailAddress1.TabIndex = 54;
            this.txtEmailAddress1.Text = " ";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(593, 52);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(91, 13);
            this.label89.TabIndex = 50;
            this.label89.Text = "EMAILADDRESS";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(846, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(133, 138);
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            // 
            // txtTITHECARDNUMBER
            // 
            this.txtTITHECARDNUMBER.Location = new System.Drawing.Point(360, 123);
            this.txtTITHECARDNUMBER.Name = "txtTITHECARDNUMBER";
            this.txtTITHECARDNUMBER.Size = new System.Drawing.Size(203, 20);
            this.txtTITHECARDNUMBER.TabIndex = 40;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(355, 107);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(91, 13);
            this.label73.TabIndex = 46;
            this.label73.Text = "TITHE CARD NO";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txtMOBILENUMBER4);
            this.groupBox9.Controls.Add(this.txtMOBILENUMBER2);
            this.groupBox9.Controls.Add(this.txtMOBILENUMBER3);
            this.groupBox9.Controls.Add(this.txtMOBILENUMBER1);
            this.groupBox9.Location = new System.Drawing.Point(105, 96);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(238, 63);
            this.groupBox9.TabIndex = 32;
            this.groupBox9.TabStop = false;
            // 
            // txtMOBILENUMBER4
            // 
            this.txtMOBILENUMBER4.Location = new System.Drawing.Point(112, 35);
            this.txtMOBILENUMBER4.MaxLength = 15;
            this.txtMOBILENUMBER4.Name = "txtMOBILENUMBER4";
            this.txtMOBILENUMBER4.Size = new System.Drawing.Size(100, 20);
            this.txtMOBILENUMBER4.TabIndex = 34;
            // 
            // txtMOBILENUMBER2
            // 
            this.txtMOBILENUMBER2.Location = new System.Drawing.Point(112, 9);
            this.txtMOBILENUMBER2.MaxLength = 15;
            this.txtMOBILENUMBER2.Name = "txtMOBILENUMBER2";
            this.txtMOBILENUMBER2.Size = new System.Drawing.Size(100, 20);
            this.txtMOBILENUMBER2.TabIndex = 33;
            // 
            // txtMOBILENUMBER3
            // 
            this.txtMOBILENUMBER3.Location = new System.Drawing.Point(6, 35);
            this.txtMOBILENUMBER3.MaxLength = 15;
            this.txtMOBILENUMBER3.Name = "txtMOBILENUMBER3";
            this.txtMOBILENUMBER3.Size = new System.Drawing.Size(100, 20);
            this.txtMOBILENUMBER3.TabIndex = 32;
            // 
            // txtMOBILENUMBER1
            // 
            this.txtMOBILENUMBER1.BackColor = System.Drawing.Color.Yellow;
            this.txtMOBILENUMBER1.Location = new System.Drawing.Point(6, 9);
            this.txtMOBILENUMBER1.MaxLength = 15;
            this.txtMOBILENUMBER1.Name = "txtMOBILENUMBER1";
            this.txtMOBILENUMBER1.Size = new System.Drawing.Size(100, 20);
            this.txtMOBILENUMBER1.TabIndex = 31;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(6, 103);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(97, 13);
            this.label80.TabIndex = 30;
            this.label80.Text = "MOBILE NUMBER";
            // 
            // dtpDATEOFBIRTH
            // 
            this.dtpDATEOFBIRTH.CustomFormat = "DD-MON-YYYY";
            this.dtpDATEOFBIRTH.Location = new System.Drawing.Point(681, 21);
            this.dtpDATEOFBIRTH.Name = "dtpDATEOFBIRTH";
            this.dtpDATEOFBIRTH.Size = new System.Drawing.Size(190, 20);
            this.dtpDATEOFBIRTH.TabIndex = 6;
            this.dtpDATEOFBIRTH.Value = new System.DateTime(1910, 1, 1, 9, 37, 0, 0);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(578, 24);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(89, 13);
            this.label81.TabIndex = 28;
            this.label81.Text = "DATE OF BIRTH";
            // 
            // cmbBLOODGROUP
            // 
            this.cmbBLOODGROUP.FormattingEnabled = true;
            this.cmbBLOODGROUP.Items.AddRange(new object[] {
            "A",
            "B",
            "AB",
            "O"});
            this.cmbBLOODGROUP.Location = new System.Drawing.Point(448, 75);
            this.cmbBLOODGROUP.Name = "cmbBLOODGROUP";
            this.cmbBLOODGROUP.Size = new System.Drawing.Size(121, 21);
            this.cmbBLOODGROUP.TabIndex = 7;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(352, 73);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(86, 13);
            this.label83.TabIndex = 24;
            this.label83.Text = "BLOOD GROUP";
            // 
            // cmbGENOTYPE
            // 
            this.cmbGENOTYPE.FormattingEnabled = true;
            this.cmbGENOTYPE.Items.AddRange(new object[] {
            "AA",
            "AO",
            "BB",
            "BO",
            "AB",
            "OO"});
            this.cmbGENOTYPE.Location = new System.Drawing.Point(448, 42);
            this.cmbGENOTYPE.Name = "cmbGENOTYPE";
            this.cmbGENOTYPE.Size = new System.Drawing.Size(121, 21);
            this.cmbGENOTYPE.TabIndex = 5;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(352, 41);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(66, 13);
            this.label84.TabIndex = 22;
            this.label84.Text = "GENOTYPE";
            // 
            // cmbGENDER
            // 
            this.cmbGENDER.BackColor = System.Drawing.Color.Yellow;
            this.cmbGENDER.FormattingEnabled = true;
            this.cmbGENDER.Location = new System.Drawing.Point(448, 18);
            this.cmbGENDER.Name = "cmbGENDER";
            this.cmbGENDER.Size = new System.Drawing.Size(121, 21);
            this.cmbGENDER.TabIndex = 3;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(352, 24);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(53, 13);
            this.label85.TabIndex = 20;
            this.label85.Text = "GENDER";
            // 
            // txtSURNAME
            // 
            this.txtSURNAME.BackColor = System.Drawing.Color.Yellow;
            this.txtSURNAME.Location = new System.Drawing.Point(105, 75);
            this.txtSURNAME.MaxLength = 50;
            this.txtSURNAME.Name = "txtSURNAME";
            this.txtSURNAME.Size = new System.Drawing.Size(238, 20);
            this.txtSURNAME.TabIndex = 2;
            this.txtSURNAME.Text = "       ";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(6, 73);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(61, 13);
            this.label86.TabIndex = 18;
            this.label86.Text = "SURNAME";
            // 
            // txtMIDDLENAME
            // 
            this.txtMIDDLENAME.Location = new System.Drawing.Point(105, 39);
            this.txtMIDDLENAME.MaxLength = 50;
            this.txtMIDDLENAME.Name = "txtMIDDLENAME";
            this.txtMIDDLENAME.Size = new System.Drawing.Size(238, 20);
            this.txtMIDDLENAME.TabIndex = 1;
            this.txtMIDDLENAME.Text = " ";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(6, 42);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(82, 13);
            this.label87.TabIndex = 16;
            this.label87.Text = "MIDDLE NAME";
            // 
            // txtFIRSTNAME
            // 
            this.txtFIRSTNAME.BackColor = System.Drawing.Color.Yellow;
            this.txtFIRSTNAME.ForeColor = System.Drawing.Color.Black;
            this.txtFIRSTNAME.Location = new System.Drawing.Point(105, 13);
            this.txtFIRSTNAME.MaxLength = 50;
            this.txtFIRSTNAME.Name = "txtFIRSTNAME";
            this.txtFIRSTNAME.Size = new System.Drawing.Size(238, 20);
            this.txtFIRSTNAME.TabIndex = 0;
            this.txtFIRSTNAME.Text = "  ";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(6, 17);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(69, 13);
            this.label88.TabIndex = 14;
            this.label88.Text = "FIRSTNAME";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnRELATIONSIP);
            this.tabPage1.Controls.Add(this.cmbMyGender);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.comboBox3);
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.cmbAssign2);
            this.tabPage1.Controls.Add(this.txtQryValue2);
            this.tabPage1.Controls.Add(this.cmbField2);
            this.tabPage1.Controls.Add(this.cmbConjunction2);
            this.tabPage1.Controls.Add(this.btnSearch);
            this.tabPage1.Controls.Add(this.txtQryValue1);
            this.tabPage1.Controls.Add(this.cmbAssign1);
            this.tabPage1.Controls.Add(this.cmbField1);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(987, 654);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Search for Members";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnRELATIONSIP
            // 
            this.btnRELATIONSIP.Location = new System.Drawing.Point(307, 3);
            this.btnRELATIONSIP.Name = "btnRELATIONSIP";
            this.btnRELATIONSIP.Size = new System.Drawing.Size(121, 23);
            this.btnRELATIONSIP.TabIndex = 52;
            this.btnRELATIONSIP.Text = "RELATIONSHIP";
            this.btnRELATIONSIP.UseVisualStyleBackColor = true;
            this.btnRELATIONSIP.Click += new System.EventHandler(this.btnRELATIONSIP_Click);
            // 
            // cmbMyGender
            // 
            this.cmbMyGender.BackColor = System.Drawing.Color.Yellow;
            this.cmbMyGender.FormattingEnabled = true;
            this.cmbMyGender.Items.AddRange(new object[] {
            "MALE",
            "FEMALE"});
            this.cmbMyGender.Location = new System.Drawing.Point(92, 3);
            this.cmbMyGender.Name = "cmbMyGender";
            this.cmbMyGender.Size = new System.Drawing.Size(179, 21);
            this.cmbMyGender.TabIndex = 50;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 13);
            this.label10.TabIndex = 51;
            this.label10.Text = "GENDER";
            this.label10.Visible = false;
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.Color.Yellow;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(455, 3);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(335, 21);
            this.comboBox3.TabIndex = 48;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged_1);
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(241, 241);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(575, 62);
            this.textBox3.TabIndex = 47;
            this.textBox3.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 244);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(170, 13);
            this.label9.TabIndex = 45;
            this.label9.Text = "SELECTED MEMBERS\' PROFILE";
            this.label9.Visible = false;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(241, 410);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(150, 25);
            this.button4.TabIndex = 42;
            this.button4.Text = "Add Dependants";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // cmbAssign2
            // 
            this.cmbAssign2.FormattingEnabled = true;
            this.cmbAssign2.Items.AddRange(new object[] {
            "=",
            ">=",
            "<=",
            ">",
            "<",
            "<>",
            "LIKE"});
            this.cmbAssign2.Location = new System.Drawing.Point(307, 54);
            this.cmbAssign2.Name = "cmbAssign2";
            this.cmbAssign2.Size = new System.Drawing.Size(121, 21);
            this.cmbAssign2.TabIndex = 41;
            // 
            // txtQryValue2
            // 
            this.txtQryValue2.Location = new System.Drawing.Point(455, 54);
            this.txtQryValue2.Name = "txtQryValue2";
            this.txtQryValue2.Size = new System.Drawing.Size(335, 20);
            this.txtQryValue2.TabIndex = 40;
            // 
            // cmbField2
            // 
            this.cmbField2.FormattingEnabled = true;
            this.cmbField2.Location = new System.Drawing.Point(92, 53);
            this.cmbField2.Name = "cmbField2";
            this.cmbField2.Size = new System.Drawing.Size(179, 21);
            this.cmbField2.TabIndex = 39;
            // 
            // cmbConjunction2
            // 
            this.cmbConjunction2.FormattingEnabled = true;
            this.cmbConjunction2.Items.AddRange(new object[] {
            "     ",
            "AND",
            "OR"});
            this.cmbConjunction2.Location = new System.Drawing.Point(4, 53);
            this.cmbConjunction2.Name = "cmbConjunction2";
            this.cmbConjunction2.Size = new System.Drawing.Size(85, 21);
            this.cmbConjunction2.TabIndex = 38;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(810, 23);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(151, 49);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click_1);
            // 
            // txtQryValue1
            // 
            this.txtQryValue1.Location = new System.Drawing.Point(455, 27);
            this.txtQryValue1.Name = "txtQryValue1";
            this.txtQryValue1.Size = new System.Drawing.Size(335, 20);
            this.txtQryValue1.TabIndex = 3;
            // 
            // cmbAssign1
            // 
            this.cmbAssign1.FormattingEnabled = true;
            this.cmbAssign1.Items.AddRange(new object[] {
            "=",
            ">=",
            "<=",
            ">",
            "<",
            "<>",
            "LIKE"});
            this.cmbAssign1.Location = new System.Drawing.Point(307, 27);
            this.cmbAssign1.Name = "cmbAssign1";
            this.cmbAssign1.Size = new System.Drawing.Size(121, 21);
            this.cmbAssign1.TabIndex = 2;
            // 
            // cmbField1
            // 
            this.cmbField1.FormattingEnabled = true;
            this.cmbField1.Location = new System.Drawing.Point(92, 27);
            this.cmbField1.Name = "cmbField1";
            this.cmbField1.Size = new System.Drawing.Size(179, 21);
            this.cmbField1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(4, 78);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(991, 157);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataridDependants);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(987, 654);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "Dependant List";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataridDependants
            // 
            this.dataridDependants.AllowUserToAddRows = false;
            this.dataridDependants.AllowUserToDeleteRows = false;
            this.dataridDependants.AllowUserToOrderColumns = true;
            this.dataridDependants.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataridDependants.Location = new System.Drawing.Point(0, 0);
            this.dataridDependants.Name = "dataridDependants";
            this.dataridDependants.ReadOnly = true;
            this.dataridDependants.Size = new System.Drawing.Size(991, 246);
            this.dataridDependants.TabIndex = 44;
            // 
            // Depandent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 679);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.comboBox7);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.txtInstitution);
            this.Controls.Add(this.txtLEVEL);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.cmbStudGrad);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.cmdBaptizedImmersion);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cmbBornAgain);
            this.Name = "Depandent";
            this.Text = "Depandent";
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataridDependants)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtInstitution;
        private System.Windows.Forms.TextBox txtLEVEL;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbStudGrad;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cmdBaptizedImmersion;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbBornAgain;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtREASON;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox cmdPREFERREDGROUP;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtSPIRITUALGIFTS;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtSPECIALSKILLS;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtHOBBIESANDINTEREST;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.DateTimePicker dtpDATEJOINED;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtPLACEOFWORKPROFESSION;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtPLACEOFWORKPHONENUMBERS;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox txtPLACEOFWORKADDRESS;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox txtPLACEOFWORK;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.ComboBox cmbEMPLOYEESTATUS;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtDEGREE3;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txtLEVEL300;
        private System.Windows.Forms.TextBox txtCourseOfStudy3;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txtACADEMICINSTITUTION3;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.ComboBox cmdStudentOrGraduate3;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox txtDEGREE2;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txtLEVEL200;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtLEVEL100;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtDEGREE0;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txtCourseOfStudy2;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox txtACADEMICINSTITUTION2;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.ComboBox cmdStudentOrGraduate2;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox txtCourseOfStudy0;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txtACADEMICINSTITUTION1;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.ComboBox cmdStudentOrGraduate1;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cmbAREYOUBAPTIZEDBYHOLYSPIRIT;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.ComboBox cmbAREYOUBAPTIZEDBYIMMERSION;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.ComboBox cmbAREYOUBORNAGAIN;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txtEmailAddress3;
        private System.Windows.Forms.TextBox txtEmailAddress2;
        private System.Windows.Forms.TextBox txtEmailAddress1;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtTITHECARDNUMBER;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox txtMOBILENUMBER4;
        private System.Windows.Forms.TextBox txtMOBILENUMBER2;
        private System.Windows.Forms.TextBox txtMOBILENUMBER3;
        private System.Windows.Forms.TextBox txtMOBILENUMBER1;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.DateTimePicker dtpDATEOFBIRTH;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.ComboBox cmbBLOODGROUP;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.ComboBox cmbGENOTYPE;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.ComboBox cmbGENDER;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox txtSURNAME;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox txtMIDDLENAME;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox txtFIRSTNAME;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox cmbAssign2;
        private System.Windows.Forms.TextBox txtQryValue2;
        private System.Windows.Forms.ComboBox cmbField2;
        private System.Windows.Forms.ComboBox cmbConjunction2;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtQryValue1;
        private System.Windows.Forms.ComboBox cmbAssign1;
        private System.Windows.Forms.ComboBox cmbField1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader Firstname;
        private System.Windows.Forms.ColumnHeader Surname;
        private System.Windows.Forms.ColumnHeader Gender;
        private System.Windows.Forms.ColumnHeader MaritalStatus;
        private System.Windows.Forms.ColumnHeader MobileNumber1;
        private System.Windows.Forms.ColumnHeader MobileNumber2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button btnRELATIONSIP;
        private System.Windows.Forms.ComboBox cmbMyGender;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataridDependants;
    }
}