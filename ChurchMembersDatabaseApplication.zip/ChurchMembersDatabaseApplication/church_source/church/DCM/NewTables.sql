CREATE TABLE [BioData] (
	[Firstname] [varchar] (50)  NOT NULL ,
	[Middlename] [varchar] (50)  NOT NULL ,
	[Lastname] [varchar] (50)  NOT NULL ,
	[Reg_no] [varchar] (50)  NOT NULL ,
	[Date_of_birth] [datetime] NULL ,
	[Street1] [varchar] (70)  NOT NULL ,
	[Street2] [varchar] (70)  NOT NULL ,
	[Location] [varchar] (50)  NOT NULL ,
	[State] [varchar] (50)  NOT NULL ,
	[Gender] [char] (1)  NOT NULL ,
	[Current_band] [varchar] (50)  NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [ChurchMembers] (
	[Member_id] [int] IDENTITY (1, 1) NOT NULL ,
	[Firstname] [varchar] (50)  NULL ,
	[Middlename] [varchar] (50)  NULL ,
	[Lastname] [varchar] (50)  NOT NULL ,
	[Gender] [varchar] (15)  NULL ,
	[MaritalStatus] [varchar] (15)  NULL ,
	[Genotype] [varchar] (50)  NULL ,
	[DateOfBirth] [datetime] NULL ,
	[BloodGroup] [varchar] (15)  NULL ,
	[Street1] [varchar] (100)  NULL ,
	[Street2] [varchar] (100)  NULL ,
	[LGACounty] [varchar] (50)  NULL ,
	[State] [varchar] (50)  NULL ,
	[Country] [varchar] (50)  NULL ,
	[TiteCardNo] [varchar] (50)  NULL ,
	[MobileNumber1] [varchar] (15)  NOT NULL ,
	[MobileNumber2] [varchar] (15)  NULL ,
	[MobileNumber3] [varchar] (15)  NULL ,
	[MobileNumber4] [varchar] (15)  NULL ,
	[SpouseMobileNumber1] [varchar] (15)  NULL ,
	[SpouseMobileNumber2] [varchar] (15)  NULL ,
	[AreYouBornAgain] [varchar] (15)  NULL ,
	[AreYouBaptizedByImmersion] [varchar] (15)  NULL ,
	[AreYouBaptizedByHolySpirit] [varchar] (15)  NULL ,
	[EmploymentStatus] [varchar] (15)  NULL ,
	[PlaceOfWork] [varchar] (100)  NULL ,
	[PlaceOfWorkAddress] [varchar] (100)  NULL ,
	[PlaceOfWorkPhone] [varchar] (100)  NULL ,
	[Profession] [varchar] (100)  NULL ,
	[DateJoined] [datetime] NULL ,
	[Hobbies] [varchar] (100)  NULL ,
	[SpecialSkills] [varchar] (100)  NULL ,
	[SpiritualGifts] [varchar] (100)  NULL ,
	[PreferredGroup] [varchar] (50)  NULL ,
	[Reason] [varchar] (100)  NULL ,
	[StudentOrGraduate1] [varchar] (50)  NULL ,
	[Institustion1] [varchar] (50)  NULL ,
	[CourseOfStudy1] [varchar] (50)  NULL ,
	[Degree1] [varchar] (50)  NULL ,
	[Level1] [varchar] (50)  NULL ,
	[StudentOrGraduate2] [varchar] (50)  NULL ,
	[Institustion2] [varchar] (50)  NULL ,
	[CourseOfStudy2] [varchar] (50)  NULL ,
	[Degree2] [varchar] (50)  NULL ,
	[Level2] [varchar] (50)  NULL ,
	[StudentOrGraduate3] [varchar] (50)  NULL ,
	[Institustion3] [varchar] (50)  NULL ,
	[CourseOfStudy3] [varchar] (50)  NULL ,
	[Degree3] [varchar] (50)  NULL ,
	[Level3] [varchar] (50)  NULL ,
	[emailaddress1] [varchar] (50)  NULL ,
	[emailaddress2] [varchar] (50)  NULL ,
	[emailaddress3] [varchar] (50)  NULL ,
	CONSTRAINT [PK_MYKEY] PRIMARY KEY  CLUSTERED 
	(
		[Lastname],
		[MobileNumber1]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO


CREATE TABLE [Country] (
	[lga_id] [int] IDENTITY (1, 1) NOT NULL ,
	[Country] [varchar] (50)  NOT NULL ,
	[State] [varchar] (50)  NOT NULL ,
	[lga] [varchar] (50)  NOT NULL ,
	CONSTRAINT [PK_MYKEYcountry] PRIMARY KEY  CLUSTERED 
	(
		[State],
		[lga]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO


CREATE TABLE [Dependant_ChurchMembers] (
	[Dependant_Member_id] [int] IDENTITY (1, 1) NOT NULL ,
	[Relationship] [varchar] (50)  NULL ,
	[Member_id] [int] NOT NULL ,
	[Firstname] [varchar] (50)  NOT NULL ,
	[Middlename] [varchar] (50)  NULL ,
	[Lastname] [varchar] (50)  NOT NULL ,
	[Gender] [varchar] (15)  NULL ,
	[MaritalStatus] [varchar] (15)  NULL ,
	[Genotype] [varchar] (50)  NULL ,
	[DateOfBirth] [datetime] NULL ,
	[BloodGroup] [varchar] (15)  NULL ,
	[Street1] [varchar] (100)  NULL ,
	[Street2] [varchar] (100)  NULL ,
	[LGACounty] [varchar] (50)  NULL ,
	[State] [varchar] (50)  NULL ,
	[Country] [varchar] (50)  NULL ,
	[TiteCardNo] [varchar] (50)  NULL ,
	[MobileNumber1] [varchar] (15)  NOT NULL ,
	[MobileNumber2] [varchar] (15)  NULL ,
	[MobileNumber3] [varchar] (15)  NULL ,
	[MobileNumber4] [varchar] (15)  NULL ,
	[SpouseMobileNumber1] [varchar] (15)  NULL ,
	[SpouseMobileNumber2] [varchar] (15)  NULL ,
	[AreYouBornAgain] [varchar] (15)  NULL ,
	[AreYouBaptizedByImmersion] [varchar] (15)  NULL ,
	[AreYouBaptizedByHolySpirit] [varchar] (15)  NULL ,
	[EmploymentStatus] [varchar] (15)  NULL ,
	[PlaceOfWork] [varchar] (100)  NULL ,
	[PlaceOfWorkAddress] [varchar] (100)  NULL ,
	[PlaceOfWorkPhone] [varchar] (100)  NULL ,
	[Profession] [varchar] (100)  NULL ,
	[DateJoined] [datetime] NULL ,
	[Hobbies] [varchar] (100)  NULL ,
	[SpecialSkills] [varchar] (100)  NULL ,
	[SpiritualGifts] [varchar] (100)  NULL ,
	[PreferredGroup] [varchar] (50)  NULL ,
	[Reason] [varchar] (100)  NULL ,
	[StudentOrGraduate1] [varchar] (50)  NULL ,
	[Institustion1] [varchar] (50)  NULL ,
	[CourseOfStudy1] [varchar] (50)  NULL ,
	[Degree1] [varchar] (50)  NULL ,
	[Level1] [varchar] (50)  NULL ,
	[StudentOrGraduate2] [varchar] (50)  NULL ,
	[Institustion2] [varchar] (50)  NULL ,
	[CourseOfStudy2] [varchar] (50)  NULL ,
	[Degree2] [varchar] (50)  NULL ,
	[Level2] [varchar] (50)  NULL ,
	[StudentOrGraduate3] [varchar] (50)  NULL ,
	[Institustion3] [varchar] (50)  NULL ,
	[CourseOfStudy3] [varchar] (50)  NULL ,
	[Degree3] [varchar] (50)  NULL ,
	[Level3] [varchar] (50)  NULL ,
	[emailaddress1] [varchar] (50)  NULL ,
	[emailaddress2] [varchar] (50)  NULL ,
	[emailaddress3] [varchar] (50)  NULL ,
	CONSTRAINT [PK_MYKEY_DEPENDANT] PRIMARY KEY  CLUSTERED 
	(
		[Member_id],
		[Lastname],
		[Firstname],
		[MobileNumber1]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO


CREATE TABLE [MYCOLUMN] (
	[FIELD_id] [int] IDENTITY (1, 1) NOT NULL ,
	[FIELDNAME] [varchar] (50)  NOT NULL ,
	[MYTABLENAME] [varchar] (50)  NOT NULL ,
	CONSTRAINT [PK_MYKEY_MYCOLUMN] PRIMARY KEY  CLUSTERED 
	(
		[MYTABLENAME],
		[FIELDNAME]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO
CREATE TABLE [RELATIONSHIP] (
	[GENDER] [varchar] (50)  NOT NULL ,
	[RELATIONSHIP_TYPE] [varchar] (50)  NOT NULL ,
	CONSTRAINT [PK_MYKEY_RELATIONSHIP_TYPE] PRIMARY KEY  CLUSTERED 
	(
		[RELATIONSHIP_TYPE],
		[GENDER]
	)  ON [PRIMARY] 
) ON [PRIMARY]
GO

